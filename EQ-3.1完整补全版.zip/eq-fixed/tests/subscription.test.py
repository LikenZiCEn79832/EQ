#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
订阅转换与新增接口回归测试（2.3.0）
用法：PORT=8794 python3 tests/subscription.test.py
"""
import os
import sys
import json
import base64
import hashlib
import urllib.request
import urllib.error
import urllib.parse

import yaml

B = os.environ.get("PORT", "8794")
if not B.startswith("http"):
    B = f"http://127.0.0.1:{B}"

UA = "Mozilla/5.0 (audit)"
KEY = "EdgeTunnel-Secret-Key"
PW = os.environ.get("ADMIN_PW", "d342d11e-d424-4583-b36e-524ab1f0afa4")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


OPENER = urllib.request.build_opener(NoRedirect)


def login(password):
    """用给定口令登录，返回可用的 Cookie 头；失败返回 None"""
    body = urllib.parse.urlencode({"password": password}).encode()
    r = urllib.request.Request(B + "/login", data=body,
                               headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"},
                               method="POST")
    try:
        resp = OPENER.open(r, timeout=20)
        raw = resp.read().decode("utf-8", "replace")
        if "success" not in raw:
            return None
    except Exception:
        return None
    tok = hashlib.md5(f"{KEY}:{password}".encode()).hexdigest()
    return {"Cookie": f"auth={tok}"}


COOKIE = login(PW)
if COOKIE is None and PW == "d342d11e-d424-4583-b36e-524ab1f0afa4":
    # 可能该实例已被改过密码，提示用 ADMIN_PW 指定
    print(f"  [提示] 默认口令登录失败（实例可能已改过密码），请设置环境变量 ADMIN_PW=<当前密码> 后重跑")
    COOKIE = {"Cookie": "auth=invalid"}

PASS, FAIL = [], []


def req(path, headers=None):
    r = urllib.request.Request(B + path, headers={"User-Agent": UA, **(headers or {})})
    try:
        resp = urllib.request.urlopen(r, timeout=30)
        return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def ctype(h):
    return {k.lower(): v for k, v in h.items()}.get("content-type", "")


def check(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name} {detail}")


print(f"=== 目标实例：{B} ===")

print("\n=== 1. 订阅多协议 ===")
s, h, b = req("/sub")
plain = base64.b64decode(b).decode()
lines = plain.splitlines()
check("base64 订阅可解码", len(lines) >= 3, f"节点数={len(lines)}")
check("含 vless 节点", any(l.startswith("vless://") for l in lines))
check("含 trojan 节点", any(l.startswith("trojan://") for l in lines))
check("含 ss 节点", any(l.startswith("ss://") for l in lines))

print("\n=== 2. 内置 subconverter：各 target ===")
s, h, b = req("/sub?target=raw")
check("target=raw 输出明文链接", b.decode().startswith("vless://"))

s, h, b = req("/sub?target=clash")
y = yaml.safe_load(b.decode())
types = [p["type"] for p in y["proxies"]]
check("Clash YAML 可解析", isinstance(y, dict) and "proxies" in y)
check("Clash 含 vless/trojan/ss", set(types) == {"vless", "trojan", "ss"}, f"types={types}")
check("Clash 规则走代理", y.get("rules") == ["MATCH,PROXY"], f"rules={y.get('rules')}")
ss_nodes = [p for p in y["proxies"] if p["type"] == "ss"]
check("Clash 的 ss 节点带 v2ray-plugin", bool(ss_nodes) and ss_nodes[0].get("plugin") == "v2ray-plugin")

s, h, b = req("/sub?target=singbox")
j = json.loads(b)
otypes = [o["type"] for o in j["outbounds"]]
check("sing-box JSON 可解析", "outbounds" in j)
check("sing-box 含三种协议", set(otypes) == {"vless", "trojan", "shadowsocks"}, f"types={otypes}")

s, h, b = req("/sub?target=surge")
t = b.decode()
check("Surge 输出含三种协议", "[Proxy]" in t and "= trojan," in t and "= vless," in t and "= ss," in t)

s, h, b = req("/sub?target=quanx")
t = b.decode()
check("Quantumult X 输出含三种协议", "trojan =" in t and "vless =" in t and "shadowsocks =" in t)

s, h, b = req("/sub?target=loon")
t = b.decode()
check("Loon 输出含三种协议", "= trojan," in t and "= vless," in t and "= ss," in t)

print("\n=== 3. 新增管理接口 ===")
s, h, b = req("/admin/kv", COOKIE)
j = json.loads(b)
check("/admin/kv 返回 JSON", "application/json" in ctype(h))
check("KV 绑定状态可读", "bound" in j and "healthy" in j,
      f"bound={j.get('bound')} binding={j.get('binding')} write={j.get('write')} storage={j.get('storage')}")

s, h, b = req("/admin/protocols", COOKIE)
j = json.loads(b)
check("/admin/protocols 可用", s == 200 and "enabled" in j, f"enabled={j.get('enabled')}")
check("trojan 段含口令", bool(j.get("trojan", {}).get("password")))
check("ss 段标注标准", j.get("ss", {}).get("standard") == "Shadowsocks AEAD（SIP007）",
      f"method={j.get('ss', {}).get('method')} path={j.get('ss', {}).get('path')}")
check("udp 段标注 DoH", j.get("udp", {}).get("mechanism") == "DNS over HTTPS")

s, h, b = req("/admin/sub-links", COOKIE)
j = json.loads(b)
check("/admin/sub-links 返回 7 种链接", len(j.get("links", [])) == 7,
      f"targets={[l['target'] for l in j.get('links', [])]}")

s, h, b = req("/admin/doh-test", COOKIE)
j = json.loads(b)
check("DoH 自检接口可用", "success" in j, f"success={j.get('success')} latency={j.get('latency')}ms")

print(f"\n===== 订阅与接口测试：通过 {len(PASS)}，失败 {len(FAIL)} =====")
if FAIL:
    print("失败项：", FAIL)
    sys.exit(1)
