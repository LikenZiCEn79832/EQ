import crypto from 'crypto';

// WebSocket 实现：Node 22+ 内置 WHATWG WebSocket 优先，否则回退 ws 包（npm i ws）
class WSAdapter {
    constructor(url) {
        this._ws = new globalThis.WebSocket(url);
        this._ws.binaryType = 'arraybuffer';
        this._handlers = {};
        this._ws.onopen = () => this._emit('open');
        this._ws.onmessage = (e) => this._emit('message', Buffer.from(e.data));
        this._ws.onerror = (e) => this._emit('error', new Error(e && e.message ? e.message : 'websocket error'));
        this._ws.onclose = () => this._emit('close');
    }
    on(evt, fn) { (this._handlers[evt] = this._handlers[evt] || []).push(fn); return this; }
    _emit(evt, arg) { (this._handlers[evt] || []).forEach(f => f(arg)); }
    send(data) { this._ws.send(data); }
    close() { try { this._ws.close(); } catch (_) { } }
    terminate() { this.close(); }
}
const WS = globalThis.WebSocket ? WSAdapter : (await import('ws')).default;

const PORT = Number(process.env.PORT || 8792);
const UUID = 'd342d11e-d424-4583-b36e-524ab1f0afa4';
const SS_PW = process.env.SS_PASSWORD || 'MySsPass456';
const SS_METHOD = process.env.SS_METHOD || 'aes-128-gcm';
const TROJAN_PW = process.env.TROJAN_PASSWORD || 'MyTrojanPass123';
const TARGET_HOST = 'example.com';
const HTTP_REQ = Buffer.from('GET / HTTP/1.1\r\nHost: example.com\r\nConnection: close\r\n\r\n');

let PASS = 0, FAIL = 0;
function check(name, ok, detail = '') {
    ok ? PASS++ : FAIL++;
    console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${name} ${detail}`);
}

function connect(path, onMessage, timeoutMs = 9000) {
    return new Promise((resolve) => {
        const ws = new WS(`ws://127.0.0.1:${PORT}${path}`);
        const chunks = [];
        let done = false;
        ws.on('message', (d) => chunks.push(Buffer.from(d)));
        ws.on('open', () => {});
        ws.on('error', (e) => { if (!done) { done = true; resolve({ error: e.message, chunks }); } });
        ws.on('close', () => { if (!done) { done = true; resolve({ chunks, closed: true }); } });
        setTimeout(() => {
            if (done) return;
            done = true;
            try { ws.close(); } catch (_) {}
            resolve({ chunks, timeout: true });
        }, timeoutMs);
        ws.__send = (buf) => ws.send(buf);
        Promise.resolve().then(() => { onMessage(ws); });
    });
}

function sendAndWait(path, packet, timeoutMs = 9000) {
    return new Promise((resolve) => {
        const ws = new WS(`ws://127.0.0.1:${PORT}${path}`);
        const chunks = [];
        let finished = false;
        const finish = (extra) => { if (finished) return; finished = true; try { ws.close(); } catch (_) {} resolve({ chunks, ...extra }); };
        ws.on('message', (d) => chunks.push(Buffer.from(d)));
        ws.on('error', (e) => finish({ error: e.message }));
        ws.on('close', () => finish({ closed: true }));
        ws.on('open', () => ws.send(packet));
        setTimeout(() => finish({ timeout: true }), timeoutMs);
    });
}

// ---------- VLESS ----------
function vlessPacket(host, port, payload, cmd = 1) {
    const ub = Buffer.from(UUID.replace(/-/g, ''), 'hex');
    const dom = Buffer.from(host);
    return Buffer.concat([
        Buffer.from([0]), ub, Buffer.from([0]), Buffer.from([cmd]),
        Buffer.from([(port >> 8) & 0xff, port & 0xff]), Buffer.from([2, dom.length]), dom, payload
    ]);
}

// ---------- Trojan ----------
function trojanPacket(host, port, payload) {
    const hex = crypto.createHash('sha224').update(TROJAN_PW).digest('hex');
    const dom = Buffer.from(host);
    return Buffer.concat([
        Buffer.from(hex, 'ascii'), Buffer.from('\r\n'),
        Buffer.from([0x01]), Buffer.from([0x03, dom.length]), dom,
        Buffer.from([(port >> 8) & 0xff, port & 0xff]), Buffer.from('\r\n'), payload
    ]);
}

// ---------- Shadowsocks AEAD (SIP007) ----------
function evpBytesToKey(password, keyLen) {
    const out = [];
    let prev = Buffer.alloc(0);
    while (Buffer.concat(out).length < keyLen) {
        prev = crypto.createHash('md5').update(Buffer.concat([prev, Buffer.from(password)])).digest();
        out.push(prev);
    }
    return Buffer.concat(out).subarray(0, keyLen);
}
function ssSealStream(psk, salt, method, keyLen) {
    const subkey = crypto.hkdfSync('sha1', psk, salt, Buffer.from('ss-subkey'), keyLen);
    const nonce = Buffer.alloc(12);
    const inc = () => { for (let i = nonce.length - 1; i >= 0; i--) { if (nonce[i] === 0xff) { nonce[i] = 0; continue; } nonce[i]++; break; } };
    return (plain) => {
        const c = crypto.createCipheriv(method, subkey, nonce, { authTagLength: 16 });
        const ct = Buffer.concat([c.update(plain), c.final()]);
        const tag = c.getAuthTag();
        inc();
        return Buffer.concat([ct, tag]);
    };
}
function ssOpenStream(psk, salt, method, keyLen) {
    const subkey = crypto.hkdfSync('sha1', psk, salt, Buffer.from('ss-subkey'), keyLen);
    const nonce = Buffer.alloc(12);
    const inc = () => { for (let i = nonce.length - 1; i >= 0; i--) { if (nonce[i] === 0xff) { nonce[i] = 0; continue; } nonce[i]++; break; } };
    return (ct) => {
        const d = crypto.createDecipheriv(method, subkey, nonce, { authTagLength: 16 });
        d.setAuthTag(ct.subarray(ct.length - 16));
        const plain = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
        inc();
        return plain;
    };
}
function ssPacket(host, port, payload, method = 'aes-128-gcm') {
    const keyLen = method === 'aes-256-gcm' ? 32 : 16;
    const psk = evpBytesToKey(SS_PW, keyLen);
    const salt = crypto.randomBytes(keyLen);
    const seal = ssSealStream(psk, salt, method, keyLen);
    const dom = Buffer.from(host);
    const addr = Buffer.concat([Buffer.from([0x03, dom.length]), dom, Buffer.from([(port >> 8) & 0xff, port & 0xff])]);
    const parts = [salt, seal(Buffer.from([(addr.length >> 8) & 0xff, addr.length & 0xff])), seal(addr)];
    if (payload && payload.length) {
        parts.push(seal(Buffer.from([(payload.length >> 8) & 0xff, payload.length & 0xff])), seal(payload));
    }
    return { packet: Buffer.concat(parts), psk, method, keyLen };
}
function ssDecodeResponse(buf, psk, method, keyLen) {
    if (buf.length < keyLen) return null;
    const salt = Buffer.from(buf.subarray(0, keyLen));
    const open = ssOpenStream(psk, salt, method, keyLen);
    let off = keyLen;
    const out = [];
    while (off + 18 <= buf.length) {
        const lenPlain = open(Buffer.from(buf.subarray(off, off + 18)));
        off += 18;
        const len = lenPlain.readUInt16BE(0);
        if (off + len + 16 > buf.length) break;
        out.push(open(Buffer.from(buf.subarray(off, off + len + 16))));
        off += len + 16;
    }
    return Buffer.concat(out);
}

// ---------- DNS 查询构造 ----------
function buildDnsQuery(domain) {
    const qname = [];
    for (const label of domain.split('.')) {
        const b = Buffer.from(label);
        qname.push(b.length, ...b);
    }
    qname.push(0);
    const header = Buffer.alloc(12);
    crypto.randomBytes(2).copy(header);
    header[2] = 0x01;
    header[5] = 0x01;
    const tail = Buffer.from([0x00, 0x01, 0x00, 0x01]);
    return Buffer.concat([header, Buffer.from(qname), tail]);
}

(async () => {
    console.log('=== A. 基准：VLESS over WS（回归） ===');
    {
        const r = await sendAndWait('/', vlessPacket(TARGET_HOST, 80, HTTP_REQ));
        const all = Buffer.concat(r.chunks);
        check('VLESS 正常转发', all.toString('latin1').includes('HTTP/1.1'), `字节=${all.length}`);
    }

    console.log('\n=== B. Trojan over WS ===');
    {
        const r = await sendAndWait('/', trojanPacket(TARGET_HOST, 80, HTTP_REQ));
        const all = Buffer.concat(r.chunks);
        check('Trojan 握手+转发', all.toString('latin1').includes('HTTP/1.1'), `字节=${all.length}`);
    }
    {
        // 错误口令应被拒绝
        const wrong = Buffer.concat([
            Buffer.from(crypto.createHash('sha224').update('wrong-password').digest('hex'), 'ascii'),
            Buffer.from('\r\n'), Buffer.from([0x01]), Buffer.from([0x03, 11]),
            Buffer.from(TARGET_HOST), Buffer.from([0x00, 80]), Buffer.from('\r\n'), HTTP_REQ
        ]);
        const r = await sendAndWait('/', wrong, 5000);
        const all = Buffer.concat(r.chunks);
        check('Trojan 错误口令被拒', all.length === 0 && (r.closed || r.timeout), `收到字节=${all.length}`);
    }

    console.log('\n=== C. Shadowsocks AEAD over WS (SIP007) ===');
    // 只测当前实例配置的加密套件（套件必须与服务端一致，否则 AEAD 校验必然失败）
    // 若要验证 aes-256-gcm：把实例的 SS_METHOD 改为 aes-256-gcm，并以 SS_METHOD=aes-256-gcm 运行本脚本
    for (const method of [SS_METHOD]) {
        const { packet, psk, keyLen } = ssPacket(TARGET_HOST, 80, HTTP_REQ, method);
        const r = await sendAndWait('/ss', packet);
        const all = Buffer.concat(r.chunks);
        let plain = null;
        try { plain = ssDecodeResponse(all, psk, method, keyLen); } catch (e) { }
        check(`SS ${method} 解密并转发`, !!plain && plain.toString('latin1').includes('HTTP/1.1'),
            `收到密文字节=${all.length}${plain ? ` 明文字节=${plain.length}` : ' 解密失败'}`);
    }
    {
        // 错误口令应被拒绝（AEAD 校验失败）
        const { psk } = ssPacket(TARGET_HOST, 80, HTTP_REQ);
        const badPsk = evpBytesToKey('WrongPassword', 16);
        const salt = crypto.randomBytes(16);
        const seal = ssSealStream(badPsk, salt, 'aes-128-gcm', 16);
        const dom = Buffer.from(TARGET_HOST);
        const addr = Buffer.concat([Buffer.from([0x03, dom.length]), dom, Buffer.from([0x00, 80])]);
        const packet = Buffer.concat([salt, seal(Buffer.from([0, addr.length])), seal(addr)]);
        // 用错口令加密，Worker 用正确口令解密必然失败
        const r = await sendAndWait('/ss', packet, 5000);
        const all = Buffer.concat(r.chunks);
        check('SS 错误口令被拒', all.length === 0, `收到字节=${all.length}`);
    }

    console.log('\n=== D. UDP：DNS over HTTPS ===');
    {
        const dom = Buffer.from(TARGET_HOST);
        const query = buildDnsQuery('example.com');
        const addrBlock = Buffer.concat([Buffer.from([2, dom.length]), dom, Buffer.from([0x00, 53])]);
        const body = Buffer.concat([addrBlock, query]);
        const udpPkt = Buffer.concat([Buffer.from([(body.length >> 8) & 0xff, body.length & 0xff]), body]);
        const first = vlessPacket(TARGET_HOST, 53, udpPkt, 2);
        const r = await sendAndWait('/', first, 12000);
        const all = Buffer.concat(r.chunks);
        let ok = false, detail = `字节=${all.length}`;
        if (all.length >= 2) {
            const len = (all[0] << 8) | all[1];
            const answer = all.subarray(2, 2 + len);
            const isResponse = (answer[2] & 0x80) === 0x80;
            const ancount = (answer[6] << 8) | answer[7];
            ok = isResponse && ancount > 0 && answer.length === len;
            detail += ` 长度字段=${len} 响应体=${answer.length} QR=${isResponse} answers=${ancount}`;
        }
        check('UDP DNS 查询经 DoH 返回应答', ok, detail);
    }
    {
        // 非 53 端口的 UDP 应被明确拒绝（不静默成功）
        const dom = Buffer.from(TARGET_HOST);
        const addrBlock = Buffer.concat([Buffer.from([2, dom.length]), dom, Buffer.from([0x1e, 0x61])]); // 7777
        const body = Buffer.concat([addrBlock, Buffer.from('hello-udp')]);
        const udpPkt = Buffer.concat([Buffer.from([(body.length >> 8) & 0xff, body.length & 0xff]), body]);
        const r = await sendAndWait('/', vlessPacket(TARGET_HOST, 7777, udpPkt, 2), 6000);
        const all = Buffer.concat(r.chunks);
        check('非 53 端口 UDP 被拒绝（无回包）', all.length === 0, `收到字节=${all.length}`);
    }

    console.log(`\n===== 协议互操作测试：通过 ${PASS}，失败 ${FAIL} =====`);
    process.exit(FAIL ? 1 : 0);
})();
