# EQ 旗舰部署版 · 2.3.0 修复 + 能力补全版

基于 Cloudflare Workers 的代理服务端。`2.2.0` 修复了四类故障；`2.3.0` 在此基础上补齐了
**多协议（Trojan / Shadowsocks）、UDP-DoH、subconverter 订阅转换**，并把 **KV 命名空间名称写死**
以便按名称创建绑定。

完整的证据、根因与回归测试结果见 **[AUDIT-REPORT.md](./AUDIT-REPORT.md)**。

---

## 一、2.3.0 新增能力

| 编号 | 能力 | 实现方式 | 验证结果 |
|---|---|---|---|
| ADD-01 | **Trojan over WebSocket** | 标准 trojan 头 `hex(SHA-224(password)) + CRLF + cmd + ATYP + ADDR + PORT + CRLF`；SHA-224 为纯 JS 实现 | 握手+转发成功，错误口令被拒；SHA-224 与 Node 内置实现 137 例逐例一致 |
| ADD-02 | **Shadowsocks AEAD over WebSocket** | SIP007：`EVP_BytesToKey(MD5)` 主密钥 + `HKDF-SHA1(info="ss-subkey")` 会话子密钥 + AES-GCM + 12 字节小端 nonce 计数器 | aes-128-gcm / aes-256-gcm 均完成「加密→服务端解密→回程加密→客户端解密」闭环 |
| ADD-03 | **UDP（DNS over HTTPS）** | VLESS/Trojan 的 UDP 报文按 2 字节长度分包；`:53` 的 DNS 查询转 DoH 请求并回封响应 | 实测返回真实 DNS 应答（QR=1，answers=2）；非 53 端口明确拒绝 |
| ADD-04 | **内置 subconverter** | 支持 `clash / singbox / surge / quanx / loon / mixed / raw`，也可转发外部 SUBAPI，失败自动回退 | 22 项订阅测试全通过 |
| ADD-05 | **KV 诊断** | `/admin/kv` 暴露绑定名、读写探测结果；面板顶部在未绑定 KV 时弹橙色告警条 | 已验证 `bound/write/healthy` 三态 |
| ADD-06 | **测试脚本随包交付** | `tests/` 下 4 个脚本，可在本地重跑全部结论 | 见「七、自测」 |

---

## 二、2.2.0 修复清单（保留）

| 编号 | 问题 | 修复 |
|---|---|---|
| FIX-01 | 日志加载失败（`/admin/log.json` 返回 HTML） | 补齐日志接口 + 全链路日志落盘 |
| FIX-02 | 选择性配置保存后刷新丢失 | 补齐 `cf.json` 写入、`tg.json`、`init`、`getCloudflareUsage`、`version`；未知接口返回 JSON 404 |
| FIX-03 | 密码无法修改 | 新增 `/admin/password` + 面板改密弹窗 + 默认口令强制改密 |
| FIX-04 | 保存静默失败（返回 200 HTML，前端误判成功） | 后台接口一律返回 JSON |
| FIX-05 | 未绑定 KV 时保存直接 500 | 降级内存存储并明确提示 |
| FIX-06 | 默认配置字段与前端不匹配 | 补齐全部字段 |
| FIX-07 | 订阅节点地址每次随机变化 | 改用后台优选节点，输出恒定 |
| FIX-08 | Clash 规则 `MATCH,DIRECT`（全直连） | 改为 `MATCH,PROXY` |
| FIX-09 | 反代回传上游 Cookie | 删除上游 `Set-Cookie` |
| FIX-10 | Cookie 绑定 UA，换浏览器掉线 | 与 UA 解耦 |
| FIX-11 | 登录可被爆破 | 每 IP 5 分钟 8 次失败后限流 |
| FIX-12 | 缓冲区复用可能串包 | 首包拷贝后再归还内存池 |
| FIX-13 | 缺 `/version`、`/admin/status` | 补齐 |

---

## 三、部署：KV 名称已写死

> **固定名称（不要改）**
> - 命名空间名称（title）：`edgetunnel-kv`
> - 绑定名（binding）：`KV`

### 方式一：Wrangler CLI（推荐，一键）

```bash
npm install                 # 安装 wrangler（也可直接用 npx）
npx wrangler login          # 首次需要登录
node setup-kv.mjs           # 自动创建 edgetunnel-kv 并把 id 回填到 wrangler.toml
npx wrangler deploy
```

`setup-kv.mjs` 的三种用法：

| 命令 | 作用 |
|---|---|
| `node setup-kv.mjs` | 自动创建 `edgetunnel-kv`；若已存在则尝试复用，并回填 id |
| `node setup-kv.mjs <32位ID>` | 已有命名空间，直接把 id 写回 `wrangler.toml` |
| `node setup-kv.mjs --check` | 只检查 id 是否已配置好 |

### 方式二：Cloudflare 控制台手动创建

1. **Workers & Pages → KV → 创建命名空间**，名称填 `edgetunnel-kv`
2. 复制命名空间 ID
3. 运行 `node setup-kv.mjs <ID>`（或手动替换 `wrangler.toml` 末尾的 `id`）

### 方式三：在线编辑器粘贴 `_worker.js`

> ⚠️ 这种方式**不会自动创建 KV 绑定**，配置只能落在内存里，冷启动后丢失。
> 你之前遇到的「保存后刷新就没了」「貌似连不上 KV」，大概率就是这个原因。

若必须用这种方式，请在控制台补齐绑定：
**Worker → 设置 → 变量 → KV 命名空间绑定 → 变量名填 `KV`（必须叫这个名字）→ 选择 `edgetunnel-kv`**

绑定完成后，登录后台访问 `/admin/kv` 应返回 `"healthy": true`；未绑定时面板顶部会有橙色告警条。

---

## 四、多协议怎么用

`wrangler.toml` 里控制订阅输出哪些协议：

```toml
PROTOCOLS = "vless,trojan,ss"     # 只要 VLESS 就改成 "vless"
TROJAN_PASSWORD = "你的trojan口令"
SS_METHOD = "aes-128-gcm"         # 或 aes-256-gcm
SS_PASSWORD = "你的SS口令"
SS_PATH = "/ss"                   # Shadowsocks 独立路径
```

| 协议 | 客户端 | 关键点 |
|---|---|---|
| VLESS | v2rayN / v2rayNG / sing-box / Clash | 主路径（`PATH`，默认 `/`），TLS + WS |
| Trojan | trojan-go / Clash / sing-box | 主路径，口令即 `TROJAN_PASSWORD`，`type=ws` |
| Shadowsocks | Shadowsocks + v2ray-plugin | 路径必须是 `/ss`，加密方式 `aes-128-gcm`，插件 `v2ray-plugin;mode=websocket;path=/ss;host=<你的域名>;tls` |

> Shadowsocks 用独立路径，是因为 SS 报文是纯密文、没有协议特征头，
> 无法与 VLESS/Trojan 在同一个路径上自动区分。

---

## 五、订阅格式

在订阅地址后加 `target=` 参数（也可在面板 `/admin/sub-links` 拿到全部链接）：

| 地址 | 输出 |
|---|---|
| `/sub` | base64 混合链接（默认，通用） |
| `/sub?target=clash` | Clash / Mihomo YAML |
| `/sub?target=singbox` | sing-box JSON |
| `/sub?target=surge` | Surge 配置片段 |
| `/sub?target=quanx` | Quantumult X 节点行 |
| `/sub?target=loon` | Loon 配置片段 |
| `/sub?target=raw` | 明文链接列表 |
| `/sub?target=<其它>` | 交给外部 subconverter（需配置 `SUBAPI`） |

也支持按 UA 自动识别（Clash / sing-box / Surge / Quantumult / Loon 会自动拿到对应格式）。

**外部 subconverter（可选）**：在 `wrangler.toml` 填 `SUBAPI = "https://你的subconverter/sub"`，
或后台 `订阅转换配置.SUBAPI`。外部调用失败会自动回退内置转换，不会让订阅挂掉。
用 `?convert=api` 强制走外部，`?convert=local` 强制内置。

---

## 六、UDP 说明（重要）

Cloudflare Workers **没有 UDP socket**，所以：

- ✅ **支持**：目标端口 `53` 的 DNS 查询 —— 转成 DoH 请求，把应答封回 UDP 报文返回
- ❌ **不支持**：其它 UDP 端口（游戏、QUIC、WireGuard 等）—— 会被明确拒绝并记日志，不做静默丢弃

DoH 上游可换：`DOH_URL = "https://dns.google/dns-query"` 或 `https://1.1.1.1/dns-query`。
自检：登录后访问 `/admin/doh-test`。

---

## 七、自测

包内 `tests/` 目录下 4 个脚本，可复现本报告的全部结论：

```bash
# 1) SHA-224 正确性（无需起服务）
node tests/sha224.test.mjs

# 2) 协议互操作（需先起本地服务，并准备 wrangler 环境）
npx wrangler dev --local --port 8792
PORT=8792 node tests/protocol.test.mjs       # 需 Node 22+（用内置 WebSocket）

# 3) 订阅转换与新增接口
PORT=8794 ADMIN_PW=你的后台密码 python3 tests/subscription.test.py

# 4) 2.2.0 全量回归（54 项，带 KV / 不带 KV 两种场景）
PORT_A=http://127.0.0.1:8794 PORT_B=http://127.0.0.1:8795 python3 tests/regression.py
```

最新一次执行结果：`SHA-224 137/137`、`协议互操作 7/7`、`订阅与接口 22/22`、`2.2.0 回归 54/54`。

---

## 八、环境变量

| 变量 | 说明 | 默认 |
|---|---|---|
| `UUID` | VLESS 节点 UUID | `d342d11e-...` |
| `ADMIN` | 后台密码 | 同 UUID |
| `KEY` | 快速订阅密钥 | `EdgeTunnel-Secret-Key` |
| `FALLBACK_SITE` | 伪装反代站点 | `https://www.bing.com` |
| `PATH` | VLESS/Trojan 的 WS 路径 | 空（根路径） |
| `PROXYIP` | 出站备用 ProxyIP 池 | 官方优选列表 |
| `PROTOCOLS` | 订阅输出协议 | `vless,trojan,ss` |
| `TROJAN_PASSWORD` | Trojan 口令 | 同 UUID |
| `SS_METHOD` | SS 加密方式 | `aes-128-gcm` |
| `SS_PASSWORD` | SS 口令 | 同 UUID |
| `SS_PATH` | SS 的 WS 路径 | `/ss` |
| `DOH_URL` | DoH 上游 | Cloudflare |
| `SUBAPI` | 外部 subconverter | 空（用内置） |
| `PAGES_BASE` | 面板前端静态源站 | `https://edt-pages.github.io` |
| `REQUIRE_SUB_TOKEN` | 订阅是否强制带 token | `false` |

---

## 九、自检接口

| 地址 | 用途 |
|---|---|
| `/version` | 版本号、存储模式、是否需改密 |
| `/admin/status` | 同上（需登录） |
| `/admin/kv` | **KV 绑定状态与读写探测结果** |
| `/admin/protocols` | 当前启用的协议、口令、SS 方法、UDP/DoH 配置 |
| `/admin/sub-links` | 各格式订阅链接 |
| `/admin/doh-test` | DoH 连通性自检 |
| `/admin/log.json` | 运行日志 |

默认后台密码：`d342d11e-d424-4583-b36e-524ab1f0afa4`（公开值，登录后请先修改）。

---

## 十、目录说明

```
_worker.js            主程序（部署只需要这一个文件）
wrangler.toml         Wrangler 配置（KV 名称已写死）
setup-kv.mjs          KV 一键创建/回填脚本
package.json          项目描述
AUDIT-REPORT.md       审计报告：问题清单、证据、回归测试
README.md             本文件
tests/
  sha224.test.mjs     SHA-224 与 Node 内置实现交叉验证
  protocol.test.mjs   VLESS / Trojan / SS / UDP-DoH 互操作测试
  subscription.test.py 订阅多格式 + 新增接口测试
  regression.py       54 项全量回归（带 KV / 不带 KV）
frontend/
  login.html          登录页
  admin.html          管理后台（已注入改密功能）
  noKV.html           未绑定 KV 提示页
  noADMIN.html        未设置管理员密码提示页
config_guide.md       客户端配置指引
clash-meta.yaml       Clash Meta 配置模板
sing-box.json         sing-box 配置模板
```

> `frontend/` 下的页面默认由 `PAGES_BASE` 源站提供（与官方原版行为一致）。
> 直接修改本地 `admin.html` **不会生效**（除非自托管并改 `PAGES_BASE`）——
> 这也是改密组件采用「回源时动态注入」的原因。

---

## 十一、已知限制（不掩饰）

1. **Shadowsocks 2022（SIP022）未实现**。其强制要求 BLAKE3 `derive_key`，Workers 无原生支持；
   纯 JS 实现无法与真实客户端做互操作验证，与其交付一个连不上的功能，不如明确不提供。
   本次提供的是 **Shadowsocks AEAD（SIP007）**，这也是 v2ray-plugin 走 WS 时实际使用的格式。
2. **Surge / Quantumult X / Loon 三种格式按公开文档语法生成**，未做真机导入验证；
   Clash 与 sing-box 已做结构化解析验证（YAML/JSON 可解析、字段完整）。
   若某个客户端导入异常，请配置 `SUBAPI` 走成熟的 subconverter。
3. **UDP 仅 53 端口**，原因见第六节，属平台限制而非实现缺陷。
4. 面板前端仍默认从第三方 Pages 回源（与原版一致）；需要完全自控请设置 `PAGES_BASE` 自托管。
