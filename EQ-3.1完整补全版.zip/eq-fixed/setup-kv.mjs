#!/usr/bin/env node
/**
 * ============================================================
 * KV 一键配置脚本（名称已写死，按名称创建即可）
 *   命名空间名称（title）：edgetunnel-kv
 *   绑定名（binding）    ：KV
 * ============================================================
 * 用法：
 *   node setup-kv.mjs            # 自动创建 edgetunnel-kv 并把 id 写回 wrangler.toml
 *   node setup-kv.mjs <KV_ID>    # 已有命名空间，直接把 id 写回 wrangler.toml
 *   node setup-kv.mjs --check    # 只检查当前配置里的 KV id 是否已填好
 * ============================================================
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const KV_TITLE = 'edgetunnel-kv';
const BINDING = 'KV';
const TOML = path.resolve(process.cwd(), 'wrangler.toml');
const PLACEHOLDER = 'REPLACE_WITH_YOUR_KV_ID';
const ID_RE = /[0-9a-f]{32}/i;

function readToml() {
    if (!fs.existsSync(TOML)) {
        console.error(`✗ 当前目录下找不到 wrangler.toml（期望路径：${TOML}）`);
        console.error('  请先 cd 到本目录再运行。');
        process.exit(1);
    }
    return fs.readFileSync(TOML, 'utf8');
}

function currentId(text) {
    const m = text.match(/id\s*=\s*"([^"]+)"/);
    return m ? m[1] : null;
}

function writeId(id) {
    const text = readToml();
    const updated = text.replace(/id\s*=\s*"(?:REPLACE_WITH_YOUR_KV_ID|[0-9a-f]{32})"/gi, `id = "${id}"`);
    fs.writeFileSync(TOML, updated, 'utf8');
    console.log(`✓ 已写入 wrangler.toml：binding = "${BINDING}", id = "${id}"`);
}

function runWrangler(args) {
    const r = spawnSync('npx', ['wrangler', ...args], { encoding: 'utf8', shell: process.platform === 'win32' });
    return {
        ok: r.status === 0,
        out: `${r.stdout || ''}${r.stderr || ''}`
    };
}

function modeCheck() {
    const text = readToml();
    const id = currentId(text);
    if (!id || id === PLACEHOLDER) {
        console.log('✗ KV 尚未配置：wrangler.toml 中的 id 仍是占位符。');
        console.log(`  请运行：node setup-kv.mjs     （会自动创建命名空间「${KV_TITLE}」）`);
        process.exit(1);
    }
    if (!ID_RE.test(id)) {
        console.log(`✗ KV id 格式异常：${id}`);
        process.exit(1);
    }
    console.log(`✓ KV 已配置：binding = "${BINDING}", id = "${id}"`);
}

function modeManual(id) {
    if (!ID_RE.test(id)) {
        console.error(`✗ 提供的 ID 不是 32 位十六进制字符串：${id}`);
        process.exit(1);
    }
    writeId(id);
    console.log('\n下一步：npx wrangler deploy');
}

function modeAuto() {
    console.log(`※ 固定名称：命名空间「${KV_TITLE}」，binding「${BINDING}」`);

    const who = runWrangler(['whoami']);
    if (!who.ok) {
        console.error('✗ 无法读取 Cloudflare 登录状态，请先执行：npx wrangler login');
        console.error(who.out.trim().split('\n').slice(0, 5).join('\n'));
        process.exit(1);
    }

    console.log('→ 尝试创建命名空间…');
    const created = runWrangler(['kv', 'namespace', 'create', KV_TITLE]);
    const out = created.out;

    let id = null;
    const mHash = out.match(/id\s*=\s*"([0-9a-f]{32})"/i);
    const mJson = out.match(/"id"\s*:\s*"([0-9a-f]{32})"/i);
    const mBare = out.match(/\b([0-9a-f]{32})\b/i);
    if (mHash) id = mHash[1];
    else if (mJson) id = mJson[1];
    else if (created.ok && mBare) id = mBare[1];

    if (id) {
        writeId(id);
        console.log('\n下一步：npx wrangler deploy');
        return;
    }

    // 多半是同名命名空间已存在，尝试从列表里找
    console.log('→ 未能直接创建（可能同名命名空间已存在），尝试在已有列表中查找…');
    const listed = runWrangler(['kv', 'namespace', 'list']);
    const line = listed.out.split('\n').find(l => l.includes(KV_TITLE));
    const found = line ? line.match(/[0-9a-f]{32}/i) : null;
    if (found) {
        writeId(found[0]);
        console.log(`  已复用已存在的命名空间「${KV_TITLE}」。`);
        console.log('\n下一步：npx wrangler deploy');
        return;
    }

    console.log('\n⚠ 自动处理失败，请手动完成（Cloudflare 控制台）：');
    console.log(`  1) Workers & Pages → KV → 创建命名空间，名称填：${KV_TITLE}`);
    console.log('  2) 复制命名空间 ID');
    console.log(`  3) 运行：node setup-kv.mjs <ID>`);
    console.log('\n  —— 或者，若你是在 Cloudflare 在线编辑器里粘贴代码部署：');
    console.log('     设置 → 变量 → KV 命名空间绑定 → 变量名填 KV → 选择 edgetunnel-kv');
    console.log('\n  原始输出：');
    console.log(out.trim().split('\n').slice(0, 12).map(l => '    ' + l).join('\n'));
    process.exit(1);
}

const arg = process.argv[2];
if (arg === '--check') modeCheck();
else if (arg && arg !== '--check') modeManual(arg);
else modeAuto();
