# EdgeTunnel 2.1 生产级部署与全套优化指南

## 一、系统架构与深度优化详解

### 1. 协议层：WebSocket 0-RTT (Early Data) 支持
- **原理**：传统 WebSocket 在 TLS 握手后还需要经历 1 个 RTT 的 HTTP 101 升级握手，延迟高。
- **优化**：本项目服务端完整支持了 RFC 6455 子协议规范，客户端可将 VLESS 握手首包经由 Base64URL 编码放入 `Sec-WebSocket-Protocol` 请求头中。服务端在建连瞬间无延迟解码并在完成 101 握手的同时直接发起出站 TCP 拨号，实现 **0-RTT 首包极速加载**。

### 2. 内存层：V8 引擎 TypedArray 预分配共享缓冲区池 (Buffer Pool)
- **原理**：海量数据传输时，如果每收到或发出一个数据块都调用 `new Uint8Array()`，会导致 V8 引擎频繁执行 GC（垃圾回收）暂停，造成网络连接偶发卡顿和抖动。
- **优化**：内置 `BufferPool`，预分配 32KB 规格的高性能共享连续内存块，按需借取、即用即还，极大降低了垃圾回收压力。

### 3. 网络与流控层：全双工背压机制 (Backpressure)
- **原理**：当代客户端下载速度远低于 Cloudflare 骨干网到目标服务器的接收速度时，Worker 内存极易发生数据堆积，触发 Cloudflare 128MB 物理内存上限被 Kill 掉。
- **优化**：
  - 上行方向监听 `tcpWriter.desiredSize`，当下游积压时暂停读取；
  - 下行方向监听 `webSocket.bufferedAmount`，当积压超出 512KB 时挂起流读取，等待排空至 64KB 后唤醒恢复传输。

### 4. 稳定性：移动端切网与僵尸连接看门狗 (Idle Watchdog)
- **原理**：手机在 4G/5G 与 Wi-Fi 切换、息屏挂起时，TCP Socket 不会发送正常的 FIN 挥手包，残留的悬挂连接会持续消耗边缘计算资源。
- **优化**：引入 90 秒活跃看门狗定时器，周期巡检无活动连接，主动销毁并释放资源。

### 5. 抗主动探测与回源伪装 (Anti-Probing)
- **原理**：防火墙主动扫描器向节点发送畸形探测请求时，普通脚本往往返回 `400 Bad Request` 或 `500 Error`，暴露出代理服务器特征。
- **优化**：任何非法握手、错误路径、普通 GET/POST 均被无缝反向代理（ProxyPass）至预设的合法 HTTPS 站点（如微软 Bing），清洗掉代理相关的专属 Header 并伪装为 Nginx 响应，实现探测器完全失真。

---

## 二、Cloudflare 后台详细配置步骤

### 方式 A：通过 Wrangler 命令行一键部署（推荐）

1. **安装 Wrangler**：
   ```bash
   npm install -g wrangler
   wrangler login
   ```

2. **创建 KV 命名空间**：
   ```bash
   wrangler kv:namespace create PROXYIP_KV
   ```
   记录输出的 `id`，替换 `wrangler.toml` 中的 `YOUR_KV_NAMESPACE_ID`。

3. **一键发布**：
   ```bash
   wrangler deploy
   ```

---

### 方式 B：通过 Cloudflare Web 控制台手动部署

#### 步骤 1：创建并部署 Worker
1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/)，点击左侧菜单 **Compute (Workers) -> Workers & Pages**。
2. 点击 **Create Application** -> **Create Worker**，命名为 `edgetunnel-v2`。
3. 点击 **Deploy**，进入代码编辑界面，将 `_worker.js` 中的全部代码复制粘贴进去，点击 **Save and Deploy**。

#### 步骤 2：创建与绑定 KV 命名空间
1. 在左侧菜单点击 **Storage & Databases** -> **KV**。
2. 点击 **Create a namespace**，命名为 `PROXYIP_KV`，点击 **Add**。
3. 返回 **Workers & Pages** -> 点击刚才创建的 `edgetunnel-v2` -> **Settings** -> **Variables**。
4. 找到 **KV Namespace Bindings** 区域，点击 **Add binding**：
   - **Variable name**: `PROXYIP_KV`（必须严格大写保持一致）
   - **KV namespace**: 选择刚创建的 `PROXYIP_KV`
5. 点击 **Save and deploy**。

#### 步骤 3：配置环境变量 (Environment Variables)
在同一 **Variables** 页面下的 **Environment Variables** 区域点击 **Add variable**：
- `UUID`: 自定义 32 位 UUID（如：`d342d11e-d424-4583-b36e-524ab1f0afa4`）
- `PATH`: WebSocket 请求路径，如 `/vless-ws`
- `FALLBACK_SITE`: 探测伪装站点，如 `https://www.bing.com`
- `PROXYIP`: 备用 ProxyIP 列表（英文逗号分隔）

#### 步骤 4：配置 Cron Trigger（定时自动测速轮换）
1. 在 Worker 详情页面，点击 **Triggers** 选项卡。
2. 向下滚动至 **Cron Triggers**，点击 **Add Cron Trigger**。
3. 输入 Cron 表达式：
   ```cron
   */5 * * * *
   ```
   （表示每 5 分钟自动执行一次预设 ProxyIP 健康测速，并将最低延迟者写入 KV）
4. 保存配置。

#### 步骤 5：绑定自定义域名并开启 ECH (Encrypted Client Hello)
1. 在 Worker 的 **Triggers** 页面，找到 **Custom Domains**，点击 **Add Custom Domain**。
2. 输入已解析在 Cloudflare 上的二级域名（例如 `tunnel.yourdomain.com`），点击 **Add Custom Domain**。
3. 开启 ECH 防阻断：
   - 进入该域名所在的主面板 -> **SSL/TLS** -> **Edge Certificates**。
   - 找到 **TLS 1.3** 并确保启用。
   - 找到 **Encrypted Client Hello (ECH)**，切换开关为 **Enabled**。
