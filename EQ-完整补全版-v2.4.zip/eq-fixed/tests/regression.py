import os
import urllib.request,urllib.error,hashlib,json,base64,yaml,sys
UA="Mozilla/5.0 (audit)"
ENV_UUID=os.environ.get("ENV_UUID","d342d11e-d424-4583-b36e-524ab1f0afa4"); KEY="EdgeTunnel-Secret-Key"; PW="d342d11e-d424-4583-b36e-524ab1f0afa4"
def md5(t): return hashlib.md5(t.encode()).hexdigest()
class NoRedir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**k): return None
op=urllib.request.build_opener(NoRedir)
def req(B,p,m="GET",body=None,headers=None,ctype="application/json"):
    h={"User-Agent":UA,**(headers or {})}; d=None
    if body is not None: d=body.encode() if isinstance(body,str) else body; h["Content-Type"]=ctype
    r=urllib.request.Request(B+p,data=d,headers=h,method=m)
    try:
        resp=op.open(r,timeout=30); return resp.status,dict(resp.headers),resp.read()
    except urllib.error.HTTPError as e: return e.code,dict(e.headers),e.read()
def ct(h): return {k.lower():v for k,v in h.items()}.get("content-type","")
PASS=[];FAIL=[]
def check(name,cond,detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name} {detail}")

def suite(B,label,withkv):
    print(f"\n########## {label} ({B}) ##########")
    s,h,b=req(B,"/version")
    check("版本接口返回JSON", "application/json" in ct(h), f"-> {s} {ct(h)}")
    j=json.loads(b)
    check("版本号为2.3.0", j.get("Version")=="2.4.0", f"-> {j.get('Version')}")
    check("storage 上报正确", j.get("storage")==("kv" if withkv else "memory"), f"-> {j.get('storage')}")
    # 登录
    s,h,b=req(B,"/login","POST",f"password={PW}",ctype="application/x-www-form-urlencoded")
    check("默认密码可登录", s==200 and json.loads(b).get("success") is True, f"-> {s}")
    check("登录下发Cookie", any(k.lower()=="set-cookie" for k in h))
    check("返回 needChangePassword 标记", json.loads(b).get("needChangePassword") is True)
    C={"Cookie":f"auth={md5(KEY+':'+PW)}"}
    # 日志
    s,h,b=req(B,"/admin/log.json",headers=C)
    check("日志接口返回JSON(修复故障1)", "application/json" in ct(h) and s==200, f"-> {s} {ct(h)}")
    try:
        json.loads(b); check("日志内容可被JSON解析", True, f"条数={len(json.loads(b))}")
    except Exception as e: check("日志内容可被JSON解析", False, str(e))
    # 未知接口
    s,h,b=req(B,"/admin/nope",headers=C)
    check("未知接口返回JSON404(修复故障2)", s==404 and "application/json" in ct(h), f"-> {s} {ct(h)}")
    # 默认口令拦截写操作
    s,h,b=req(B,"/admin/config.json","POST",'{"UUID":"x"}',headers=C)
    check("默认口令下禁止写操作(修复故障3前提)", s==403, f"-> {s}")
    # 改密
    NEW="NewPass2026ok"
    s,h,b=req(B,"/admin/password","POST",json.dumps({"oldPassword":PW,"newPassword":NEW}),headers=C)
    check("改密成功(修复故障3)", s==200 and json.loads(b).get("success") is True, f"-> {s} {json.loads(b).get('message','')}")
    C2={"Cookie":f"auth={md5(KEY+':'+NEW)}"}
    s,h,b=req(B,"/login","POST",f"password={NEW}",ctype="application/x-www-form-urlencoded")
    check("新密码可登录", s==200)
    s,h,b=req(B,"/admin/status",headers=C2)
    check("改密后不再强制改密", json.loads(b).get("needChangePassword") is False)
    # 保存各类配置
    for n,p,body,c,expect in [("config.json","/admin/config.json",'{"UUID":"11111111-2222-4333-8444-555555555555","HOSTS":["h1.com"]}',"application/json","11111111-2222-4333-8444-555555555555"),
                              ("cf.json","/admin/cf.json",'{"ZoneID":"z9"}',"application/json","z9"),
                              ("tg.json","/admin/tg.json",'{"Token":"tg9"}',"application/json","tg9")]:
        s,h,b=req(B,p,"POST",body,headers=C2)
        check(f"保存 {n}", s==200, f"-> {s} storage={json.loads(b).get('storage')}")
        s,h,b=req(B,p,headers=C2)
        if p!="/admin/config.json":
            ok = (expect in b.decode())
        else:
            got = json.loads(b)
            # FIX-15 新契约：环境变量 UUID 优先于 KV 保存值
            ok = (got.get("UUID")==expect) or (got.get("uuidSource")=="env" and got.get("UUID")==ENV_UUID)
        check(f"回读 {n} 一致(修复故障2)", ok, f"-> {b[:60].decode()}")
    s,h,b=req(B,"/admin/ADD.txt","POST","5.5.5.5:443#mynode",headers=C2,ctype="text/plain")
    s,h,b=req(B,"/admin/ADD.txt",headers=C2)
    check("保存并回读 ADD.txt", b.decode().strip()=="5.5.5.5:443#mynode", f"-> {b.decode().strip()}")
    # 订阅
    outs=[]
    for _ in range(3):
        s,h,b=req(B,"/sub"); outs.append(base64.b64decode(b).decode())
    check("订阅内容3次一致(修复故障4)", len(set(outs))==1, f"节点数={len(outs[0].splitlines())}")
    check("订阅节点地址为用户配置的优选节点", "5.5.5.5" in outs[0], f"-> {outs[0].splitlines()[0][:80]}")
    s,h,b=req(B,"/sub?clash"); d=yaml.safe_load(b.decode())
    check("Clash规则走代理(修复故障4)", d["rules"]==["MATCH,PROXY"], f"-> {d['rules']}")
    s,h,b=req(B,"/sub?singbox"); j=json.loads(b)
    check("sing-box 输出可用", len(j["outbounds"])>=1, f"-> {len(j['outbounds'])} outbound")
    s,h,b=req(B,"/sub?token=bad")
    check("错误token被拒", s==403, f"-> {s}")
    # 重置
    s,h,b=req(B,"/admin/init",headers=C2)
    check("重置接口可用", s==200 and json.loads(b).get("success") is True, f"-> {s}")
    s,h,b=req(B,"/admin/log.json",headers=C2)
    check("日志已累积记录", len(json.loads(b))>0, f"条数={len(json.loads(b))}")

suite(os.environ.get("PORT_A","http://127.0.0.1:8802"),"场景A：已绑定 KV",True)
suite(os.environ.get("PORT_B","http://127.0.0.1:8803"),"场景B：未绑定 KV（内存兜底）",False)
print(f"\n===== 汇总：通过 {len(PASS)} 项，失败 {len(FAIL)} 项 =====")
if FAIL:
    print("失败项：")
    for f in FAIL: print("  -",f)
    sys.exit(1)
