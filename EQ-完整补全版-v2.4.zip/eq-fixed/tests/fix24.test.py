#!/usr/bin/env python3
"""
2.4.0 线上问题专项回归：FIX-14 / FIX-15 / FIX-16 / FIX-17

这 4 个问题全部来自真实部署反馈（面板日志 NaN、改了 UUID 不生效、配置表单全空、
/version 明文暴露 UUID），每一个都先在本地 workerd 中复现，再修复，再验证。

用法：
    # 需要一个环境变量 UUID 与默认值不同的实例（模拟"用户改了 UUID 重新部署"）
    PORT=8787 ENV_UUID=<实例环境变量里的UUID> python3 tests/fix24.test.py

实例示例（wrangler.toml 的 [vars]）：
    UUID = "75133411-ff36-4bc4-86da-35df72292c91"   # 必须不是出厂默认值
"""

import os
import sys
import json
import base64
import hashlib
import datetime
import urllib.request
import urllib.error
import urllib.parse

B = os.environ.get("PORT", "http://127.0.0.1:8787")
UA = "Mozilla/5.0 (fix24-audit) Chrome/120.0"
KEY = os.environ.get("KEY", "EdgeTunnel-Secret-Key")
PW = os.environ.get("ADMIN_PW", "d342d11e-d424-4583-b36e-524ab1f0afa4")
ENV_UUID = os.environ.get("ENV_UUID", "d342d11e-d424-4583-b36e-524ab1f0afa4")
STALE_UUID = os.environ.get("STALE_UUID", "d342d11e-d424-4583-b36e-524ab1f0afa4")
DEFAULT_UUID = "d342d11e-d424-4583-b36e-524ab1f0afa4"

PASS, FAIL = [], []


def check(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name} {detail}")


def md5(t):
    return hashlib.md5(t.encode()).hexdigest()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


OPENER = urllib.request.build_opener(NoRedirect)


def req(p, m="GET", body=None, headers=None, ctype="application/json"):
    h = {"User-Agent": UA, **(headers or {})}
    d = None
    if body is not None:
        d = body.encode()
        h["Content-Type"] = ctype
    r = urllib.request.Request(B + p, data=d, headers=h, method=m)
    try:
        resp = OPENER.open(r, timeout=30)
        return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()
    except Exception as e:
        return "ERR", {}, str(e).encode()


def ctype(h):
    return {k.lower(): v for k, v in h.items()}.get("content-type", "")


def login(password):
    body = urllib.parse.urlencode({"password": password}).encode()
    r = urllib.request.Request(B + "/login", data=body,
                               headers={"User-Agent": UA,
                                        "Content-Type": "application/x-www-form-urlencoded"},
                               method="POST")
    try:
        resp = OPENER.open(r, timeout=20)
        if "success" not in resp.read().decode("utf-8", "replace"):
            return None
    except Exception:
        return None
    return {"Cookie": f"auth={md5(KEY + ':' + password)}"}


print("=" * 72)
print(f"目标实例: {B}")
print(f"环境变量 UUID: {ENV_UUID}")
print("=" * 72)

C = login(PW)
if C is None:
    print("默认口令登录失败，请通过环境变量 ADMIN_PW 指定当前后台密码后重跑")
    sys.exit(1)

# 出厂默认口令下所有写操作会被 403 拦截，必须先改密，
# 否则后续"写入 KV 再读回"的用例会静默变成假通过。
s, _, b = req("/admin/status", headers=C)
if s == 200 and json.loads(b).get("needChangePassword"):
    NEW = os.environ.get("NEW_PW", "Fix24Pass2026")
    s, _, b = req("/admin/password", "POST",
                  json.dumps({"oldPassword": PW, "newPassword": NEW}), headers=C)
    if s != 200:
        print(f"改密失败（status={s}），无法继续写入类用例")
        sys.exit(1)
    C = {"Cookie": f"auth={md5(KEY + ':' + NEW)}"}
    print(f"  [准备] 已修改默认口令，解锁写操作")

# ---------------------------------------------------------------- FIX-15
print("\n### FIX-15：环境变量 UUID 必须优先于 KV 中保存的旧 UUID")
if ENV_UUID == DEFAULT_UUID:
    print("  [跳过] 当前实例环境变量 UUID 等于出厂默认值，无法验证优先级。"
          "请用 ENV_UUID=<非默认值> 的实例运行本用例。")
else:
    # 把一份"旧 UUID"写进 KV，模拟用户改环境变量前保存过的历史配置
    req("/admin/config.json", "POST",
        json.dumps({"UUID": STALE_UUID, "HOST": "example.com"}), headers=C)
    s, h, b = req("/admin/config.json", headers=C)
    cfg = json.loads(b)
    print(f"      KV 里写入的旧 UUID : {STALE_UUID}")
    print(f"      生效 UUID          : {cfg.get('UUID')}  (source={cfg.get('uuidSource')})")
    check("环境变量 UUID 覆盖 KV 旧值",
          cfg.get("UUID") == ENV_UUID, f"-> {cfg.get('UUID')}")
    check("uuidSource 标记为 env", cfg.get("uuidSource") == "env")

    s, h, b = req("/sub")
    node = base64.b64decode(b).decode().splitlines()[0]
    sub_uuid = node[node.index("//") + 2:node.index("@")]
    print(f"      订阅生成的 UUID     : {sub_uuid}")
    check("订阅发出的 UUID == 环境变量 UUID（修复前是旧值，导致握手失败）",
          sub_uuid == ENV_UUID, f"-> {sub_uuid}")

# ---------------------------------------------------------------- FIX-14
print("\n### FIX-14：日志字段必须对齐前端契约（TIME/IP/CC/ASN/TYPE/UA/URL）")
req("/sub")            # 触发 Get_SUB 访问日志
req("/admin/log.json", headers=C)   # 触发一次读取
s, h, b = req("/admin/log.json", headers=C)
check("日志接口返回 JSON", "application/json" in ctype(h) and s == 200)
logs = json.loads(b)
check("日志非空", len(logs) > 0, f"条数={len(logs)}")
if logs:
    l = logs[0]
    missing = [f for f in ("TIME", "IP", "CC", "ASN", "TYPE", "UA", "URL") if l.get(f) is None]
    print(f"      首条日志: {json.dumps(l, ensure_ascii=False)[:160]}")
    check("前端所需 7 个字段全部存在", not missing, f"缺失={missing}")
    check("TIME 是数字时间戳（前端做 b.TIME-a.TIME 排序）",
          isinstance(l.get("TIME"), (int, float)), f"type={type(l.get('TIME')).__name__}")
    # 复现原缺陷：字符串时间戳会让前端 formatTime 得到 NaN
    t = l.get("TIME")
    try:
        d = datetime.datetime.utcfromtimestamp((t + 8 * 3600 * 1000) / 1000)
        fmt = d.strftime("%Y-%m-%d %H:%M:%S")
        ok = "NaN" not in fmt
    except Exception:
        fmt = "NaN-NaN-NaN"
        ok = False
    check("模拟前端 formatTime(log.TIME) 不再得到 NaN", ok, f"-> {fmt}")
    check("TYPE 可被前端 translateLogType 识别",
          l.get("TYPE") in ("Get_SUB", "Admin_Login", "Save_Config",
                            "Init_Config", "Save_Custom_IPs", "System", "Warning"),
          f"-> {l.get('TYPE')}")
    check("存在 Get_SUB 访问日志", any(x.get("TYPE") == "Get_SUB" for x in logs))

# ---------------------------------------------------------------- FIX-16
print("\n### FIX-16：KV 中存了空值/残缺配置时，面板表单不应全空")
req("/admin/config.json", "POST", json.dumps({
    "UUID": ENV_UUID, "HOST": "", "HOSTS": [], "PATH": "",
    "协议类型": "", "Fingerprint": "",
    "优选订阅生成": {"SUBNAME": ""}, "TG": None
}), headers=C)
s, h, b = req("/admin/config.json", headers=C)
cfg = json.loads(b)
fields = {
    "HOST": cfg.get("HOST"),
    "HOSTS": cfg.get("HOSTS"),
    "PATH": cfg.get("PATH"),
    "协议类型": cfg.get("协议类型"),
    "Fingerprint": cfg.get("Fingerprint"),
    "SUBNAME": cfg.get("优选订阅生成", {}).get("SUBNAME"),
}
for k, v in fields.items():
    print(f"      {k:12} = {v!r}")
check("HOST 有兜底值", bool(fields["HOST"]))
check("HOSTS 非空数组", isinstance(fields["HOSTS"], list) and len(fields["HOSTS"]) > 0)
check("PATH 非空", bool(fields["PATH"]))
check("协议类型有兜底值", bool(fields["协议类型"]))
check("Fingerprint 有兜底值", bool(fields["Fingerprint"]))
check("SUBNAME 有兜底值", bool(fields["SUBNAME"]))
check("嵌套对象 TG 未丢失", isinstance(cfg.get("TG"), dict), f"-> {cfg.get('TG')}")

# ---------------------------------------------------------------- FIX-17
print("\n### FIX-17：/version 未鉴权不得明文暴露完整 UUID")
s, h, b = req("/version")
j = json.loads(b)
uuid_field = j.get("UUID", "")
print(f"      /version UUID = {uuid_field}")
if ENV_UUID == DEFAULT_UUID:
    check("UUID 已掩码（不含完整 UUID）", uuid_field != ENV_UUID, f"-> {uuid_field}")
else:
    check("UUID 已掩码（不含完整 UUID）", ENV_UUID not in uuid_field, f"-> {uuid_field}")
check("掩码格式保留首尾", uuid_field.startswith(ENV_UUID[:8]) and
      uuid_field.endswith(ENV_UUID[-12:]), f"-> {uuid_field}")

# 已登录后台仍应能看到完整 UUID（便于运维）
s, h, b = req("/admin/status", headers=C)
st = json.loads(b)
print(f"      /admin/status UUID = {st.get('uuid')} (source={st.get('uuidSource')})")
check("登录后 status 显示完整 UUID", st.get("uuid") == ENV_UUID)
check("status 暴露 uuidSource", st.get("uuidSource") in ("env", "kv", "default"))

print(f"\n===== 2.4.0 专项回归：通过 {len(PASS)}，失败 {len(FAIL)} =====")
if FAIL:
    for f in FAIL:
        print("  失败 -", f)
    sys.exit(1)
