/**
 * =========================================================================
 * EdgeTunnel 2.4.0 - 修复版 + 能力补全版 (Audit-Fixed & Feature-Complete Build)
 * 基于 LikenZiCEn79832/EQ 2.1 版本修复，对标 cmliu/edgetunnel 原版能力补齐
 * =========================================================================
 * 本次修复（均附可复现证据，详见 AUDIT-REPORT.md）：
 *  FIX-01 补齐 /admin/log.json 日志接口与日志落盘（原缺失 -> 日志加载失败）
 *  FIX-02 补齐 /admin/cf.json 写入、/admin/tg.json、/admin/init（原缺失 -> 保存无效）
 *  FIX-03 补齐 /admin/password 改密接口 + 默认口令强制改密（原无改密能力）
 *  FIX-04 未知 /admin/* 一律返回 JSON 错误，不再回吐 HTML 页面（原静默失败）
 *  FIX-05 KV 未绑定时降级为内存存储并明确提示，不再直接 500
 *  FIX-06 默认配置补齐前端所需全部字段（订阅转换配置/TG/CF/SS/ECHConfig 等）
 *  FIX-07 订阅节点地址不再随机（原每次请求随机 ProxyIP），并支持 clash/sing-box/mixed
 *  FIX-08 Clash 订阅规则由 MATCH,DIRECT 修正为走代理
 *  FIX-09 反代伪装不再回传上游 Set-Cookie，且不再回显内部资源地址
 *  FIX-10 鉴权 Cookie 不再绑定 User-Agent；本地 http 调试自动放宽 Secure
 *  FIX-11 登录失败限流，缓解默认口令被公开后的爆破风险
 *  FIX-12 BufferPool 首包缓冲改为拷贝后再回收，消除跨连接内存复用串包隐患
 *  FIX-13 补齐 /version、/admin/status、/admin/getCloudflareUsage
 * 2.3.0 能力补齐：
 *  ADD-01 多协议：Trojan over WS（SHA-224 口令校验）+ Shadowsocks AEAD over WS（SIP007）
 *  ADD-02 UDP：53 端口 DNS 查询转 DoH 回封（Workers 无 UDP socket，其它端口明确拒绝）
 *  ADD-03 subconverter：内置 clash/singbox/surge/quanx/loon/mixed/raw 转换 + 外部 SUBAPI 转发与回退
 *  ADD-04 KV 诊断接口 /admin/kv，直接暴露绑定状态与读写结果
 * 2.4.0 线上问题修复（用户实测反馈，均先复现后修复）：
 *  FIX-14 日志字段契约：后端写 time/level/message，前端读 TIME/IP/CC/ASN/TYPE/UA/URL，
 *         导致面板日志列显示 NaN-NaN-NaN / 未知 / undefined
 *  FIX-15 UUID 环境变量被 KV 覆盖：订阅发出旧 UUID、服务端却用环境变量校验 -> 握手必然失败
 *  FIX-16 配置字段自愈：KV 里存了空值/旧版本配置时面板表单全空
 *  FIX-17 /version 未鉴权即暴露完整 UUID，改为掩码显示
 *  ADD-06 新增 Get_SUB 访问日志（30 分钟去重），/admin/status 暴露 uuidSource
 * 保留并验证有效：0-RTT Early Data、全双工背压、Cron 优选轮换、抗主动探测反代
 * =========================================================================
 */

import { connect } from 'cloudflare:sockets';

// ======================== 全局常量 ========================
const VERSION = '2.4.0';
const DEFAULT_UUID = 'd342d11e-d424-4583-b36e-524ab1f0afa4';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const DEFAULT_FALLBACK_SITE = 'https://www.bing.com';
const DEFAULT_PAGES_BASE = 'https://edt-pages.github.io';
const DEFAULT_PROXY_IPS = [
    'cdn.xn--b6gac.eu.org',
    'cdn-all.xn--b6gac.eu.org',
    'edgetunnel.anycast.eu.org',
    'cloudflare.net'
];

const HIGH_WATER_MARK = 512 * 1024;
const LOW_WATER_MARK = 64 * 1024;
const IDLE_TIMEOUT_MS = 90 * 1000;
const LOG_MAX_ENTRIES = 200;
const LOGIN_MAX_FAILURES = 8;
const LOGIN_WINDOW_MS = 5 * 60 * 1000;

const VLESS_RESP_HEADER = new Uint8Array([0, 0]);

// KV 未绑定时的内存兜底存储（进程内有效，重启丢失，仅用于保证面板可用）
const memoryStore = new Map();
// 登录失败计数（内存态，用于限流）
const loginFailures = new Map();

// ======================== 存储抽象（KV 优先，内存兜底） ========================
function getKvNamespace(env) {
    if (env.KV && typeof env.KV.get === 'function') return env.KV;
    if (env.PROXYIP_KV && typeof env.PROXYIP_KV.get === 'function') return env.PROXYIP_KV;
    return null;
}

function storageMode(env) {
    return getKvNamespace(env) ? 'kv' : 'memory';
}

async function kvGet(env, key) {
    const kv = getKvNamespace(env);
    if (kv) {
        try {
            const val = await kv.get(key);
            if (val !== null && val !== undefined) return val;
            return null;
        } catch (err) {
            await pushLog(env, 'warn', `KV 读取失败(${key})：${err.message}，已回退内存存储`);
        }
    }
    return memoryStore.has(key) ? memoryStore.get(key) : null;
}

async function kvPut(env, key, value, options) {
    const kv = getKvNamespace(env);
    if (kv) {
        try {
            await kv.put(key, value, options);
            return 'kv';
        } catch (err) {
            await pushLog(env, 'warn', `KV 写入失败(${key})：${err.message}，已回退内存存储`);
        }
    }
    memoryStore.set(key, value);
    return 'memory';
}

// ======================== 日志系统（FIX-01） ========================
/**
 * 从请求中提取日志上下文。
 * 字段名必须严格对齐前端 admin.html 的渲染契约（loadLogs / showAllLogs）：
 *   TIME(数字毫秒时间戳) / IP / CC / ASN / TYPE / UA / URL
 * 前端 translateLogType 识别：Get_SUB / Admin_Login / Save_Config / Init_Config / Save_Custom_IPs
 */
function logContext(request, type) {
    const ctx = { TYPE: type, IP: '', CC: '', ASN: '', UA: '', URL: '' };
    if (!request) return ctx;
    try {
        const cf = request.cf || {};
        ctx.IP = request.headers.get('CF-Connecting-IP')
            || (request.headers.get('X-Forwarded-For') || '').split(',')[0].trim()
            || '';
        ctx.CC = cf.country ? `${cf.country} ${cf.city || 'N/A'}` : '';
        ctx.ASN = cf.asn ? `AS${cf.asn} ${cf.asOrganization || 'Unknown'}` : '';
        ctx.UA = request.headers.get('User-Agent') || '';
        ctx.URL = request.url || '';
    } catch (_) { }
    return ctx;
}

async function pushLog(env, level, message, ctx = null) {
    try {
        let logs = [];
        const raw = await kvGet(env, 'log.json');
        if (raw) {
            try {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) logs = parsed;
            } catch (_) { logs = []; }
        }
        // FIX-14：此前写成 { time, level, message }，与前端期望的
        // { TIME, IP, CC, ASN, TYPE, UA, URL } 完全不匹配，
        // 导致面板日志列显示 NaN-NaN-NaN / 未知 / undefined。
        const entry = ctx && typeof ctx === 'object' ? ctx : {};
        logs.unshift({
            TIME: Date.now(),
            TYPE: entry.TYPE || (level === 'warn' || level === 'error' ? 'Warning' : 'System'),
            IP: entry.IP || '',
            CC: entry.CC || '',
            ASN: entry.ASN || '',
            UA: entry.UA || '',
            URL: entry.URL || '',
            MSG: String(message || ''),
            level: String(level || 'info')
        });
        if (logs.length > LOG_MAX_ENTRIES) logs = logs.slice(0, LOG_MAX_ENTRIES);
        await kvPut(env, 'log.json', JSON.stringify(logs));
    } catch (_) {
        // 日志失败绝不能影响主流程
    }
}

/**
 * 访问日志（去重写入）：对齐原版 30 分钟窗口，避免订阅刷新把日志刷爆。
 * 原版对 Get_SUB 不去重，但本实现日志上限更小（LOG_MAX_ENTRIES），故一并去重。
 */
async function pushAccessLogDedup(env, request, type) {
    try {
        const ctx = logContext(request, type);
        let logs = [];
        const raw = await kvGet(env, 'log.json');
        if (raw) {
            try { const p = JSON.parse(raw); if (Array.isArray(p)) logs = p; } catch (_) { logs = []; }
        }
        const cutoff = Date.now() - 30 * 60 * 1000;
        const duplicated = logs.some(l =>
            l.TYPE === type && l.IP === ctx.IP && l.URL === ctx.URL && l.UA === ctx.UA && Number(l.TIME) >= cutoff
        );
        if (duplicated) return;
        logs.unshift(Object.assign(ctx, { TIME: Date.now(), MSG: type, level: 'info' }));
        if (logs.length > LOG_MAX_ENTRIES) logs = logs.slice(0, LOG_MAX_ENTRIES);
        await kvPut(env, 'log.json', JSON.stringify(logs));
    } catch (_) { }
}

// ======================== 内存池 ========================
class BufferPool {
    constructor(blockSize = 32 * 1024, maxBlocks = 32) {
        this.blockSize = blockSize;
        this.maxBlocks = maxBlocks;
        this.pool = [];
    }
    acquire(minSize) {
        if (minSize <= this.blockSize && this.pool.length > 0) return this.pool.pop();
        return new Uint8Array(Math.max(minSize, this.blockSize));
    }
    release(buffer) {
        if (buffer && buffer.byteLength === this.blockSize && this.pool.length < this.maxBlocks) {
            this.pool.push(buffer);
        }
    }
}
const globalBufferPool = new BufferPool(32 * 1024, 32);

// ======================== 加密与哈希 ========================
const parsedUuidCache = new Map();

function getUuidBytes(uuidStr) {
    if (!uuidStr) return null;
    const cleanUuid = uuidStr.replace(/-/g, '').toLowerCase();
    if (cleanUuid.length !== 32) return null;
    if (parsedUuidCache.has(cleanUuid)) return parsedUuidCache.get(cleanUuid);
    const bytes = new Uint8Array(16);
    for (let i = 0; i < 16; i++) {
        const val = parseInt(cleanUuid.substring(i * 2, i * 2 + 2), 16);
        if (Number.isNaN(val)) return null;
        bytes[i] = val;
    }
    if (parsedUuidCache.size >= 64) parsedUuidCache.clear();
    parsedUuidCache.set(cleanUuid, bytes);
    return bytes;
}

function constantTimeCompare(a, b, offsetA = 0, length = 16) {
    if (!a || !b || a.byteLength < offsetA + length || b.byteLength < length) return false;
    let diff = 0;
    for (let i = 0; i < length; i++) diff |= (a[offsetA + i] ^ b[i]);
    return diff === 0;
}

async function md5Hex(text) {
    const enc = new TextEncoder().encode(text);
    let hashBuf;
    try {
        hashBuf = await crypto.subtle.digest('MD5', enc);
    } catch (_) {
        hashBuf = await crypto.subtle.digest('SHA-256', enc);
    }
    return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function base64UrlToUint8Array(base64Str) {
    try {
        let b64 = base64Str.replace(/-/g, '+').replace(/_/g, '/');
        while (b64.length % 4) b64 += '=';
        const binStr = atob(b64);
        const bytes = new Uint8Array(binStr.length);
        for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
        return bytes;
    } catch (_) {
        return null;
    }
}

function base64Encode(text) {
    const bytes = new TextEncoder().encode(text);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
}

// ======================== 多协议支持（2.3.0 新增） ========================
/*
 * Workers 运行环境没有原生 UDP socket，也没有 SHA-224 / BLAKE3 原生实现，
 * 因此本节按「能可靠验证」的原则补齐：
 *   VLESS over WS   —— 已有，保持不变
 *   Trojan over WS  —— 口令校验为 hex(SHA-224(password))，SHA-224 用纯 JS 实现
 *                      （已用 Node 内置 sha224 交叉验证，见 tests/protocol.test.mjs）
 *   Shadowsocks AEAD（SIP007：aes-128-gcm / aes-256-gcm）
 *                    —— 子密钥用 HKDF-SHA1(info="ss-subkey")，nonce 为 12 字节
 *                      小端计数器，与 v2ray-plugin 的 ws 模式格式一致
 *   UDP             —— 仅支持 :53 的 DNS 查询转 DoH 回封；其它端口明确拒绝，
 *                      不做“假装支持”的静默丢弃
 * 未实现：Shadowsocks 2022（SIP022）—— 其强制要求 BLAKE3 derive_key，Workers
 *         无原生支持，纯 JS 实现无法与真实客户端做互操作验证，故不提供，避免交付
 *         看似可用实则连不上的功能。详见 AUDIT-REPORT.md「已知限制」。
 */
const TROJAN_CMD_TCP = 0x01;
const TROJAN_CMD_UDP = 0x03;
const SS_METHOD_KEY_LEN = { 'aes-128-gcm': 16, 'aes-256-gcm': 32 };
const SS_NONCE_LEN = 12;
const SS_TAG_LEN = 16;
const DNS_PORT = 53;
const DEFAULT_DOH_URL = 'https://cloudflare-dns.com/dns-query';

// ---------- SHA-224（纯 JS；WebCrypto 不支持 SHA-224，而 Trojan 口令哈希正是 SHA-224） ----------
const SHA256_K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);

function sha224Hex(inputStr) {
    const bytes = new TextEncoder().encode(inputStr);
    const bitLen = bytes.length * 8;
    // 填充：1 字节 0x80 + 8 字节长度，向上取整到 64 字节块。
    // 注意必须用 +8 而不是 +9，否则长度恰好 ≡55 (mod 64) 时会多算一个块（曾导致 Trojan 口令校验失败）
    const total = (((bytes.length + 8) >> 6) + 1) << 6;
    const padded = new Uint8Array(total);
    padded.set(bytes);
    padded[bytes.length] = 0x80;
    const dv = new DataView(padded.buffer);
    dv.setUint32(total - 8, Math.floor(bitLen / 4294967296), false);
    dv.setUint32(total - 4, bitLen >>> 0, false);

    let h0 = 0xc1059ed8, h1 = 0x367cd507, h2 = 0x3070dd17, h3 = 0xf70e5939,
        h4 = 0xffc00b31, h5 = 0x68581511, h6 = 0x64f98fa7, h7 = 0xbefa4fa4;
    const w = new Uint32Array(64);

    for (let off = 0; off < total; off += 64) {
        for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4, false);
        for (let i = 16; i < 64; i++) {
            const x = w[i - 15], y = w[i - 2];
            const s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
            const s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
            w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
        }
        let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
        for (let i = 0; i < 64; i++) {
            const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
            const ch = (e & f) ^ (~e & g);
            const t1 = (h + S1 + ch + SHA256_K[i] + w[i]) >>> 0;
            const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
            const maj = (a & b) ^ (a & c) ^ (b & c);
            const t2 = (S0 + maj) >>> 0;
            h = g; g = f; f = e; e = (d + t1) >>> 0;
            d = c; c = b; b = a; a = (t1 + t2) >>> 0;
        }
        h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
        h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
    }

    const out = new Uint8Array(28);
    const odv = new DataView(out.buffer);
    odv.setUint32(0, h0, false); odv.setUint32(4, h1, false); odv.setUint32(8, h2, false);
    odv.setUint32(12, h3, false); odv.setUint32(16, h4, false); odv.setUint32(20, h5, false);
    odv.setUint32(24, h6, false);
    let hex = '';
    for (let i = 0; i < 28; i++) hex += out[i].toString(16).padStart(2, '0');
    return hex; // 56 个字符，即 Trojan 头部
}

// ---------- 通用地址解析（VLESS / Trojan / SS / UDP 复用） ----------
function readAddressPort(buffer, offset) {
    if (buffer.byteLength < offset + 1) return { hasError: true, message: '缺少地址类型' };
    const atyp = buffer[offset];
    let idx = offset + 1;
    let address = '';
    switch (atyp) {
        case 1:
            if (buffer.byteLength < idx + 4) return { hasError: true, message: '截断的 IPv4' };
            address = `${buffer[idx]}.${buffer[idx + 1]}.${buffer[idx + 2]}.${buffer[idx + 3]}`;
            idx += 4;
            break;
        case 2:
        case 3: {
            if (buffer.byteLength < idx + 1) return { hasError: true, message: '截断的域名长度' };
            const len = buffer[idx];
            idx += 1;
            if (buffer.byteLength < idx + len) return { hasError: true, message: '截断的域名' };
            address = new TextDecoder().decode(buffer.subarray(idx, idx + len));
            idx += len;
            break;
        }
        case 4: {
            if (buffer.byteLength < idx + 16) return { hasError: true, message: '截断的 IPv6' };
            const parts = [];
            for (let i = 0; i < 8; i++) parts.push(((buffer[idx + i * 2] << 8) | buffer[idx + i * 2 + 1]).toString(16));
            address = parts.join(':');
            idx += 16;
            break;
        }
        default:
            return { hasError: true, message: `不支持的地址类型: ${atyp}` };
    }
    if (buffer.byteLength < idx + 2) return { hasError: true, message: '截断的端口' };
    const port = (buffer[idx] << 8) | buffer[idx + 1];
    idx += 2;
    return { hasError: false, address, port, endIndex: idx, atyp };
}

// ---------- Trojan over WebSocket ----------
function parseTrojanHeader(buffer, expectedHex) {
    if (buffer.byteLength < 58) return { hasError: true, message: 'Trojan 头过短' };
    const hexPart = new TextDecoder().decode(buffer.subarray(0, 56));
    if (!constantTimeEqualString(hexPart, expectedHex)) {
        return { hasError: true, message: 'Trojan 口令校验失败' };
    }
    if (buffer[56] !== 0x0d || buffer[57] !== 0x0a) {
        return { hasError: true, message: 'Trojan 头缺少 CRLF' };
    }
    const cmd = buffer[58];
    if (cmd !== TROJAN_CMD_TCP && cmd !== TROJAN_CMD_UDP) {
        return { hasError: true, message: `不支持的 Trojan 命令: ${cmd}` };
    }
    const addrInfo = readAddressPort(buffer, 59);
    if (addrInfo.hasError) return addrInfo;
    if (buffer.byteLength < addrInfo.endIndex + 2) {
        return { hasError: true, message: 'Trojan 头缺少结尾 CRLF' };
    }
    if (buffer[addrInfo.endIndex] !== 0x0d || buffer[addrInfo.endIndex + 1] !== 0x0a) {
        return { hasError: true, message: 'Trojan 头结尾不是 CRLF' };
    }
    return {
        hasError: false,
        isUdp: cmd === TROJAN_CMD_UDP,
        address: addrInfo.address,
        port: addrInfo.port,
        rawPayload: buffer.subarray(addrInfo.endIndex + 2)
    };
}

function constantTimeEqualString(a, b) {
    if (a.length !== b.length) return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++) diff |= (a.charCodeAt(i) ^ b.charCodeAt(i));
    return diff === 0;
}

// ---------- Shadowsocks AEAD（SIP007：aes-128-gcm / aes-256-gcm） ----------
/**
 * 注意：这里用的是 SS AEAD（2017，SIP007）而不是 SS 2022（SIP022）。
 * 原因见本节顶部注释：SIP022 强制 BLAKE3 derive_key，Workers 无原生支持。
 * v2ray-plugin / shadowsocks-libev / Shadowsocks-Android 等主流客户端默认走的
 * 就是 AEAD 2017，配合 ws 传输（v2ray-plugin）可直接使用。
 */
async function ssDeriveSubkey(pskBytes, salt) {
    const baseKey = await crypto.subtle.importKey('raw', pskBytes, 'HKDF', false, ['deriveBits', 'deriveKey']);
    return await crypto.subtle.deriveKey(
        { name: 'HKDF', hash: 'SHA-1', salt, info: new TextEncoder().encode('ss-subkey') },
        baseKey,
        { name: 'AES-GCM', length: pskBytes.length * 8 },
        false,
        ['encrypt', 'decrypt']
    );
}

function ssIncreaseNonce(nonce) {
    for (let i = nonce.length - 1; i >= 0; i--) {
        if (nonce[i] === 0xff) { nonce[i] = 0; continue; }
        nonce[i] += 1;
        break;
    }
}

class SsInboundStream {
    constructor(pskBytes) {
        this.psk = pskBytes;
        this.keyLen = pskBytes.length;
        this.buffer = new Uint8Array(0);
        this.stage = 'salt';
        this.nonce = new Uint8Array(SS_NONCE_LEN);
        this.expectedLen = 0;
        this.cipherKey = null;
        this.headerParsed = false;
        this.target = null;
    }
    append(chunk) {
        const merged = new Uint8Array(this.buffer.length + chunk.length);
        merged.set(this.buffer, 0);
        merged.set(chunk, this.buffer.length);
        this.buffer = merged;
    }
    async pump() {
        const payloads = [];
        for (let guard = 0; guard < 4096; guard++) {
            if (this.stage === 'salt') {
                if (this.buffer.length < this.keyLen) break;
                const salt = this.buffer.slice(0, this.keyLen);
                this.buffer = this.buffer.slice(this.keyLen);
                this.cipherKey = await ssDeriveSubkey(this.psk, salt);
                this.stage = 'len';
                continue;
            }
            if (this.stage === 'len') {
                if (this.buffer.length < 2 + SS_TAG_LEN) break;
                const ct = this.buffer.slice(0, 2 + SS_TAG_LEN);
                this.buffer = this.buffer.slice(2 + SS_TAG_LEN);
                const lenBytes = await this.open(ct);
                this.expectedLen = (lenBytes[0] << 8) | lenBytes[1];
                this.stage = 'data';
                continue;
            }
            if (this.stage === 'data') {
                if (this.buffer.length < this.expectedLen + SS_TAG_LEN) break;
                const ct = this.buffer.slice(0, this.expectedLen + SS_TAG_LEN);
                this.buffer = this.buffer.slice(this.expectedLen + SS_TAG_LEN);
                const plain = await this.open(ct);
                if (!this.headerParsed) {
                    const addrInfo = readAddressPort(plain, 0);
                    if (addrInfo.hasError) throw new Error(`SS 地址头解析失败：${addrInfo.message}`);
                    this.headerParsed = true;
                    this.target = { address: addrInfo.address, port: addrInfo.port };
                } else {
                    payloads.push(plain);
                }
                this.stage = 'len';
                continue;
            }
        }
        return payloads;
    }
    async open(ct) {
        const plain = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: this.nonce, tagLength: SS_TAG_LEN * 8 },
            this.cipherKey,
            ct
        );
        ssIncreaseNonce(this.nonce);
        return new Uint8Array(plain);
    }
}

class SsOutboundStream {
    constructor(pskBytes) {
        this.psk = pskBytes;
        this.keyLen = pskBytes.length;
        this.salt = crypto.getRandomValues(new Uint8Array(this.keyLen));
        this.nonce = new Uint8Array(SS_NONCE_LEN);
        this.cipherKey = null;
        this.saltSent = false;
    }
    async ensureKey() {
        if (!this.cipherKey) this.cipherKey = await ssDeriveSubkey(this.psk, this.salt);
        return this.cipherKey;
    }
    /** 返回若干字节：首次调用会带上 salt */
    async sealChunks(data) {
        await this.ensureKey();
        const out = [];
        if (!this.saltSent) {
            out.push(this.salt.slice());
            this.saltSent = true;
        }
        let offset = 0;
        while (offset < data.length) {
            const take = Math.min(data.length - offset, 0xFFFF);
            const chunk = data.slice(offset, offset + take);
            offset += take;
            const lenBytes = new Uint8Array([(take >> 8) & 0xff, take & 0xff]);
            out.push(await this.seal(lenBytes));
            out.push(await this.seal(chunk));
        }
        return out;
    }
    async seal(plain) {
        const ct = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: this.nonce, tagLength: SS_TAG_LEN * 8 },
            this.cipherKey,
            plain
        );
        ssIncreaseNonce(this.nonce);
        return new Uint8Array(ct);
    }
}

// ---------- UDP：分包读取与 DNS-over-HTTPS ----------
/**
 * VLESS / Trojan 的 UDP 载荷是「2 字节长度 + [地址头] + 数据」的连续序列。
 * 这里只做分包与封包，真正的出站只支持 :53 的 DNS（转 DoH）。
 */
class UdpPacketReader {
    constructor() { this.buffer = new Uint8Array(0); }
    append(chunk) {
        const merged = new Uint8Array(this.buffer.length + chunk.length);
        merged.set(this.buffer, 0);
        merged.set(chunk, this.buffer.length);
        this.buffer = merged;
    }
    /** 读取下一个 UDP 报文，返回 {address, port, data}；不足一个完整报文返回 null */
    next() {
        if (this.buffer.length < 2) return null;
        const len = (this.buffer[0] << 8) | this.buffer[1];
        if (len === 0 || this.buffer.length < 2 + len) return null;
        const body = this.buffer.slice(2, 2 + len);
        this.buffer = this.buffer.slice(2 + len);
        const addrInfo = readAddressPort(body, 0);
        if (addrInfo.hasError) return { hasError: true, message: addrInfo.message };
        return {
            hasError: false,
            address: addrInfo.address,
            port: addrInfo.port,
            data: body.slice(addrInfo.endIndex)
        };
    }
}

function encodeUdpResponse(data) {
    const out = new Uint8Array(2 + data.length);
    out[0] = (data.length >> 8) & 0xff;
    out[1] = data.length & 0xff;
    out.set(data, 2);
    return out;
}

/** 构造一个最小可用的 DNS 查询报文（用于 DoH 连通性自检） */
function buildDnsQuery(domain, qtype = 1) {
    const labels = domain.split('.').filter(Boolean);
    const qname = [];
    for (const label of labels) {
        const bytes = new TextEncoder().encode(label);
        qname.push(bytes.length, ...bytes);
    }
    qname.push(0);
    const header = new Uint8Array(12);
    crypto.getRandomValues(header.subarray(0, 2));
    header[2] = 0x01; // 标准查询
    header[5] = 0x01; // QDCOUNT = 1
    const tail = new Uint8Array([(qtype >> 8) & 0xff, qtype & 0xff, 0x00, 0x01]);
    const out = new Uint8Array(12 + qname.length + 4);
    out.set(header, 0);
    out.set(Uint8Array.from(qname), 12);
    out.set(tail, 12 + qname.length);
    return out;
}

async function resolveDnsOverHttps(queryWire, dohUrl) {
    const resp = await fetch(dohUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/dns-message',
            'Accept': 'application/dns-message'
        },
        body: queryWire
    });
    if (!resp.ok) throw new Error(`DoH 服务返回 HTTP ${resp.status}`);
    return new Uint8Array(await resp.arrayBuffer());
}

// ======================== ProxyIP 管理 ========================
let cachedBestProxyIP = null;
let cacheExpiryTimestamp = 0;

async function getBestProxyIP(env) {
    const now = Date.now();
    if (cachedBestProxyIP && now < cacheExpiryTimestamp) return cachedBestProxyIP;
    const fromStore = await kvGet(env, 'BEST_PROXY_IP');
    if (fromStore && fromStore.trim()) {
        cachedBestProxyIP = fromStore.trim();
        cacheExpiryTimestamp = now + 30000;
        return cachedBestProxyIP;
    }
    return getFallbackProxyIP(env);
}

function getFallbackProxyIP(env) {
    let pool = DEFAULT_PROXY_IPS;
    if (env.PROXYIP) {
        const list = env.PROXYIP.split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean);
        if (list.length > 0) pool = list;
    }
    return pool[Math.floor(Math.random() * pool.length)];
}

// ======================== 口令与鉴权（FIX-03 / FIX-10 / FIX-11） ========================
async function getAdminPassword(env) {
    const stored = await kvGet(env, 'ADMIN_PASSWORD');
    if (stored && stored.trim()) {
        return { password: stored.trim(), custom: true };
    }
    const fromEnv = (env.ADMIN || env.admin || env.PASSWORD || env.password || env.UUID || DEFAULT_UUID).trim();
    return { password: fromEnv, custom: false };
}

/** 是否仍在使用出厂默认口令（决定是否需要强制改密） */
async function usingDefaultPassword(env) {
    const info = await getAdminPassword(env);
    if (info.custom) return false;
    return info.password === DEFAULT_UUID;
}

async function buildAuthToken(secretKey, password) {
    return await md5Hex(`${secretKey}:${password}`);
}

function clientIP(request) {
    return request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For') || 'unknown';
}

function loginAllowed(ip) {
    const now = Date.now();
    const rec = loginFailures.get(ip);
    if (!rec || now > rec.resetAt) return true;
    return rec.count < LOGIN_MAX_FAILURES;
}

function noteLoginFailure(ip) {
    const now = Date.now();
    const rec = loginFailures.get(ip);
    if (!rec || now > rec.resetAt) {
        loginFailures.set(ip, { count: 1, resetAt: now + LOGIN_WINDOW_MS });
    } else {
        rec.count += 1;
    }
    if (loginFailures.size > 5000) loginFailures.clear();
}

function clearLoginFailures(ip) {
    loginFailures.delete(ip);
}

// ======================== 主入口 ========================
export default {
    async fetch(request, env, ctx) {
        try {
            const url = new URL(request.url);
            const pathname = url.pathname;
            const upgradeHeader = (request.headers.get('Upgrade') || '').toLowerCase();
            const configuredUuid = (env.UUID || DEFAULT_UUID).trim().toLowerCase();
            const secretKey = env.KEY || 'EdgeTunnel-Secret-Key';

            // 1. WebSocket 代理（VLESS / Trojan 走主路径，Shadowsocks 走 SS_PATH）
            if (upgradeHeader === 'websocket') {
                const ssPath = normalizeWsPath(env.SS_PATH || '/ss');
                if (env.PATH) {
                    const requiredPath = normalizeWsPath(env.PATH);
                    if (pathname !== requiredPath && pathname !== ssPath) {
                        return await handleAntiProbingProxyPass(request, env);
                    }
                }
                return await handleProxyWebSocket(request, env, configuredUuid);
            }

            // 2. 版本接口（前端 /version 依赖，原缺失导致被反代到伪装站）
            if (pathname === '/version') {
                return jsonResponse({
                    Version: VERSION,
                    version: VERSION,
                    UUID: maskUuid(configuredUuid),
                    uuidSource: resolveUuidSource(env, null),
                    storage: storageMode(env),
                    needChangePassword: await usingDefaultPassword(env)
                });
            }

            // 3. 快速订阅 /<KEY>
            const cleanPath = pathname.replace(/^\/+/, '');
            if (cleanPath && cleanPath === secretKey) {
                const subToken = await md5Hex(url.hostname + configuredUuid);
                return Response.redirect(`${url.protocol}//${url.host}/sub?token=${subToken}`, 302);
            }

            // 4. 管理面板与后台 API
            const panelResponse = await handleWebPanelRouting(request, env, url, pathname, configuredUuid, secretKey);
            if (panelResponse) return panelResponse;

            // 5. 订阅
            if (pathname === '/sub' || pathname.startsWith('/sub/')) {
                return await handleSubscriptionRouting(request, env, url, configuredUuid);
            }

            // 6. robots
            if (pathname === '/robots.txt') {
                return new Response('User-agent: *\nDisallow: /', {
                    status: 200,
                    headers: { 'Content-Type': 'text/plain; charset=UTF-8' }
                });
            }

            // 7. 兜底伪装反代
            return await handleAntiProbingProxyPass(request, env);
        } catch (err) {
            try {
                await pushLog(env, 'error', `请求处理异常：${err && err.message ? err.message : err}`);
            } catch (_) { }
            return await handleAntiProbingProxyPass(request, env);
        }
    },

    async scheduled(event, env, ctx) {
        ctx.waitUntil(handleScheduledProxyCheck(env));
    }
};

function jsonResponse(obj, status = 200, extraHeaders = {}) {
    return new Response(JSON.stringify(obj, null, 2), {
        status,
        headers: { 'Content-Type': 'application/json; charset=utf-8', ...extraHeaders }
    });
}

// ======================== 面板路由 ========================
async function handleWebPanelRouting(request, env, url, pathname, configuredUuid, secretKey) {
    const adminInfo = await getAdminPassword(env);
    const adminPassword = adminInfo.password;
    const needChangePassword = await usingDefaultPassword(env);
    const authExpected = await buildAuthToken(secretKey, adminPassword);
    const cookies = request.headers.get('Cookie') || '';
    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1]?.trim();
    const isAuthed = !!authCookie && authCookie === authExpected;
    const secureFlag = url.protocol === 'https:' ? ' Secure;' : '';

    // A. 登录
    if (pathname === '/login') {
        if (isAuthed) return Response.redirect(`${url.protocol}//${url.host}/admin`, 302);
        if (request.method === 'POST') {
            const ip = clientIP(request);
            if (!loginAllowed(ip)) {
                return jsonResponse({ success: false, message: '尝试次数过多，请 5 分钟后重试' }, 429);
            }
            try {
                let inputPassword = '';
                const contentType = request.headers.get('content-type') || '';
                if (contentType.includes('application/json')) {
                    const body = await request.json();
                    inputPassword = body.password || '';
                } else {
                    const params = new URLSearchParams(await request.text());
                    inputPassword = params.get('password') || '';
                }
                if (inputPassword && inputPassword.trim() === adminPassword) {
                    clearLoginFailures(ip);
                    await pushLog(env, 'info', `管理员登录成功（IP ${ip}）`, logContext(request, 'Admin_Login'));
                    const resp = jsonResponse({
                        success: true,
                        message: '登录成功',
                        needChangePassword
                    });
                    resp.headers.append('Set-Cookie', `auth=${authExpected}; Path=/; Max-Age=86400; HttpOnly;${secureFlag} SameSite=Lax`);
                    return resp;
                }
                noteLoginFailure(ip);
                await pushLog(env, 'warn', `管理员登录失败（IP ${ip}）`, logContext(request, 'Admin_Login'));
                return jsonResponse({ success: false, message: '密码错误' }, 401);
            } catch (_) {
                return jsonResponse({ success: false, message: '请求格式错误' }, 400);
            }
        }
        return await proxyStaticPages(env, '/login');
    }

    // B. 退出
    if (pathname === '/logout') {
        const resp = Response.redirect(`${url.protocol}//${url.host}/login`, 302);
        resp.headers.append('Set-Cookie', `auth=; Path=/; Max-Age=0; HttpOnly;${secureFlag} SameSite=Lax`);
        return resp;
    }

    // C. 兼容原版的提示页路由
    if (pathname === '/noKV' || pathname === '/noADMIN') {
        return await proxyStaticPages(env, '/' + pathname.slice(1));
    }

    // D. 管理面板
    if (pathname === '/admin' || pathname.startsWith('/admin/')) {
        if (!isAuthed) return Response.redirect(`${url.protocol}//${url.host}/login`, 302);

        // 未修改默认口令时，只允许查看与改密，禁止任何写操作（FIX-03）
        const writeBlocked = needChangePassword && request.method !== 'GET' && request.method !== 'HEAD'
            && pathname !== '/admin/password';

        if (pathname === '/admin/password') {
            return await handleChangePassword(request, env, adminPassword);
        }
        if (pathname === '/admin/status') {
            const savedCfg = await loadConfig(env, url.hostname, configuredUuid);
            return jsonResponse({
                version: VERSION,
                storage: storageMode(env),
                needChangePassword,
                passwordCustom: adminInfo.custom,
                uuid: resolveEffectiveUuid(env, savedCfg, configuredUuid),
                uuidSource: resolveUuidSource(env, savedCfg)
            });
        }
        if (writeBlocked) {
            return jsonResponse({
                error: '请先修改默认管理密码后再进行其它操作',
                needChangePassword: true
            }, 403);
        }
        return await handleAdminApi(request, env, url, pathname, configuredUuid);
    }

    return null;
}

// ======================== 改密接口（FIX-03） ========================
async function handleChangePassword(request, env, currentPassword) {
    if (request.method !== 'POST') {
        return jsonResponse({ error: '请使用 POST 提交', needChangePassword: true }, 405);
    }
    try {
        const body = await request.json();
        const oldPassword = String(body.oldPassword || body.password || '');
        const newPassword = String(body.newPassword || '');
        if (!newPassword || newPassword.length < 6) {
            return jsonResponse({ success: false, message: '新密码至少 6 位' }, 400);
        }
        if (oldPassword.trim() !== currentPassword) {
            return jsonResponse({ success: false, message: '当前密码不正确' }, 401);
        }
        const mode = await kvPut(env, 'ADMIN_PASSWORD', newPassword.trim());
        await pushLog(env, 'info', `管理员密码已修改（存储：${mode}）`, logContext(request, 'Admin_Login'));
        if (mode === 'memory') {
            return jsonResponse({
                success: true,
                message: '密码已修改，但未绑定 KV，重启后会恢复为环境变量中的口令',
                storage: mode
            });
        }
        return jsonResponse({ success: true, message: '密码已修改，请使用新密码重新登录', storage: mode });
    } catch (_) {
        return jsonResponse({ success: false, message: '请求格式错误' }, 400);
    }
}

// ======================== 管理 API ========================
async function handleAdminApi(request, env, url, pathname, configuredUuid) {
    // 1. 配置读写
    if (pathname === '/admin/config.json') {
        if (request.method === 'POST') {
            const newConfig = await request.json();
            const mode = await kvPut(env, 'config.json', JSON.stringify(newConfig, null, 2));
            await pushLog(env, 'info', `配置已保存（存储：${mode}）`, logContext(request, 'Save_Config'));
            return jsonResponse({
                success: true,
                message: mode === 'kv' ? '配置已更新并保存到 KV' : '配置已保存到内存（未绑定 KV，重启丢失）',
                storage: mode
            });
        }
        // FIX-16：读取时做字段自愈，保证面板表单始终有值可填充
        const currentConfig = await loadConfig(env, url.hostname, configuredUuid);
        return jsonResponse(currentConfig);
    }

    // 2. 优选 IP / 节点列表
    if (pathname === '/admin/ADD.txt') {
        if (request.method === 'POST') {
            const customIPs = await request.text();
            const mode = await kvPut(env, 'ADD.txt', customIPs);
            await pushLog(env, 'info', `优选节点列表已保存（存储：${mode}）`, logContext(request, 'Save_Custom_IPs'));
            return jsonResponse({
                success: true,
                message: mode === 'kv' ? '优选 IP 已保存' : '优选 IP 已保存到内存（未绑定 KV，重启丢失）',
                storage: mode
            });
        }
        let addTxt = await kvGet(env, 'ADD.txt');
        if (!addTxt || addTxt.trim() === '' || addTxt.trim() === 'null') {
            addTxt = DEFAULT_PROXY_IPS.map(ip => `${ip}:443#官方优选`).join('\n');
        }
        return new Response(addTxt, {
            status: 200,
            headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
    }

    // 3. Cloudflare API 配置（原版仅有 GET，POST 被忽略 -> 保存无效）
    if (pathname === '/admin/cf.json') {
        if (request.method === 'POST') {
            const body = await request.json();
            if (body && body.init === true) {
                const mode = await kvPut(env, 'cf.json', JSON.stringify({}));
                await pushLog(env, 'info', 'Cloudflare API 配置已清除', logContext(request, 'Save_Config'));
                return jsonResponse({ success: true, message: 'Cloudflare 配置已清除', storage: mode });
            }
            const mode = await kvPut(env, 'cf.json', JSON.stringify(body, null, 2));
            await pushLog(env, 'info', `Cloudflare API 配置已保存（存储：${mode}）`, logContext(request, 'Save_Config'));
            return jsonResponse({
                success: true,
                message: mode === 'kv' ? 'Cloudflare 配置已保存到 KV' : 'Cloudflare 配置已保存到内存',
                storage: mode
            });
        }
        const raw = await kvGet(env, 'cf.json');
        let cfConfig = {};
        if (raw) {
            try { cfConfig = JSON.parse(raw); } catch (_) { cfConfig = {}; }
        }
        return jsonResponse(cfConfig);
    }

    // 4. Cloudflare 用量查询
    if (pathname === '/admin/getCloudflareUsage') {
        try {
            const usage = await getCloudflareUsage(
                url.searchParams.get('Email'),
                url.searchParams.get('GlobalAPIKey'),
                url.searchParams.get('AccountID'),
                url.searchParams.get('ZoneID')
            );
            return jsonResponse(usage);
        } catch (err) {
            return jsonResponse({ msg: '查询请求量失败：' + err.message, error: err.message }, 502);
        }
    }

    // 5. 日志读取（原缺失 -> 前端解析 HTML 失败）
    if (pathname === '/admin/log.json') {
        const raw = await kvGet(env, 'log.json');
        if (!raw) return new Response('[]', { status: 200, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
        try {
            JSON.parse(raw);
            return new Response(raw, { status: 200, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
        } catch (_) {
            return new Response('[]', { status: 200, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
        }
    }

    // 6. Telegram 通知配置（原缺失）
    if (pathname === '/admin/tg.json') {
        if (request.method === 'POST') {
            const body = await request.json();
            let cfg = {};
            const raw = await kvGet(env, 'tg.json');
            if (raw) { try { cfg = JSON.parse(raw); } catch (_) { cfg = {}; } }
            if (body && body.init === true) cfg = {};
            else cfg = Object.assign({}, cfg, body);
            const mode = await kvPut(env, 'tg.json', JSON.stringify(cfg, null, 2));
            await pushLog(env, 'info', `Telegram 配置已更新（存储：${mode}）`, logContext(request, 'Save_Config'));
            return jsonResponse({ success: true, message: '通知配置已保存', storage: mode });
        }
        const raw = await kvGet(env, 'tg.json');
        let cfg = {};
        if (raw) { try { cfg = JSON.parse(raw); } catch (_) { cfg = {}; } }
        return jsonResponse(cfg);
    }

    // 7. 恢复默认配置（原缺失）
    if (pathname === '/admin/init') {
        const defaults = generateDefaultConfig(url.hostname, configuredUuid, env);
        const mode = await kvPut(env, 'config.json', JSON.stringify(defaults, null, 2));
        await kvPut(env, 'ADD.txt', DEFAULT_PROXY_IPS.map(ip => `${ip}:443#官方优选`).join('\n'));
        await pushLog(env, 'info', `配置已重置为默认值（存储：${mode}）`, logContext(request, 'Init_Config'));
        return jsonResponse({ success: true, message: '配置已重置为默认值', storage: mode });
    }

    // 8. 连通性检测
    if (pathname === '/admin/check') {
        const bestIp = await getBestProxyIP(env);
        const latency = await measureTcpLatency(bestIp, 443, 2000);
        return jsonResponse({ success: latency.healthy, bestProxyIP: bestIp, latency: latency.latency });
    }

    // 9. Cloudflare 连接信息（只读）
    if (pathname === '/admin/cf-info') {
        return jsonResponse(request.cf || {});
    }

    // 10. KV 连通性自检（2.3.0：直接告诉用户 KV 到底连没连上）
    if (pathname === '/admin/kv') {
        const kv = getKvNamespace(env);
        const bindingName = env.KV ? 'KV' : (env.PROXYIP_KV ? 'PROXYIP_KV' : null);
        const probeKey = '__kv_probe__';
        let writeOk = false;
        let readOk = false;
        let error = null;
        if (kv) {
            try {
                const stamp = 'probe-' + Date.now();
                await kv.put(probeKey, stamp, { expirationTtl: 60 });
                const back = await kv.get(probeKey);
                writeOk = back === stamp;
                readOk = writeOk;
            } catch (err) {
                error = err.message;
            }
        }
        return jsonResponse({
            bound: !!kv,
            binding: bindingName,
            storage: storageMode(env),
            write: writeOk,
            read: readOk,
            error,
            storedKeys: ['config.json', 'ADD.txt', 'cf.json', 'tg.json', 'log.json', 'ADMIN_PASSWORD', 'BEST_PROXY_IP'],
            healthy: !!kv && writeOk,
            hint: kv
                ? (writeOk ? 'KV 绑定正常，配置会持久保存' : `KV 已绑定但读写失败：${error || '未知错误'}`)
                : '未检测到 KV 绑定，配置仅存内存，Worker 冷启动后丢失。请创建 KV 命名空间并在 wrangler.toml 中绑定（binding 名固定为 KV）。'
        });
    }

    // 11. 当前协议能力（2.3.0）
    if (pathname === '/admin/protocols') {
        const config = await loadConfig(env, url.hostname, configuredUuid);
        const trojan = loadTrojanCredential(env, config);
        const ss = await loadSsCredential(env, config);
        return jsonResponse({
            version: VERSION,
            enabled: resolveEnabledProtocols(env, config),
            vless: { enabled: true, uuid: configuredUuid, path: normalizeWsPath(env.PATH) },
            trojan: {
                enabled: true,
                password: trojan.password,
                path: normalizeWsPath(env.PATH),
                note: '口令校验使用 hex(SHA-224(password))'
            },
            ss: {
                enabled: !!ss,
                method: ss ? ss.method : null,
                password: ss ? ss.password : null,
                path: normalizeWsPath(env.SS_PATH || '/ss'),
                standard: 'Shadowsocks AEAD（SIP007）',
                note: ss ? '' : '当前 method 不受支持（仅 aes-128-gcm / aes-256-gcm），或运行环境缺少 MD5 支持'
            },
            udp: {
                supportedPorts: [53],
                mechanism: 'DNS over HTTPS',
                dohUrl: (env.DOH_URL || DEFAULT_DOH_URL).trim(),
                note: 'Workers 无 UDP socket，53 端口的 DNS 查询转 DoH 回封，其它 UDP 端口明确拒绝'
            },
            ss2022: { enabled: false, reason: 'SIP022 强制 BLAKE3 derive_key，Workers 无原生支持，未实现以免交付不可用功能' }
        });
    }

    // 12. 各格式订阅链接（2.3.0，方便面板直接取用）
    if (pathname === '/admin/sub-links') {
        const token = await md5Hex(url.hostname + configuredUuid);
        const base = `${url.protocol}//${url.host}/sub?token=${token}`;
        return jsonResponse({
            token,
            quickPath: `/${env.KEY || 'EdgeTunnel-Secret-Key'}`,
            links: ['mixed', 'clash', 'singbox', 'surge', 'quanx', 'loon', 'raw'].map(t => ({
                target: t,
                url: `${base}&target=${t}`
            }))
        });
    }

    // 13. DoH 连通性测试（2.3.0）
    if (pathname === '/admin/doh-test') {
        const dohUrl = (url.searchParams.get('url') || env.DOH_URL || DEFAULT_DOH_URL).trim();
        const start = Date.now();
        try {
            const answer = await resolveDnsOverHttps(buildDnsQuery('example.com'), dohUrl);
            return jsonResponse({ success: true, dohUrl, bytes: answer.length, latency: Date.now() - start });
        } catch (err) {
            return jsonResponse({ success: false, dohUrl, error: err.message }, 502);
        }
    }

    // 14. 面板页面（仅在精确匹配 /admin 时返回页面）
    if (pathname === '/admin' || pathname === '/admin/') {
        return await proxyStaticPages(env, '/admin' + url.search);
    }

    // FIX-04：未知后台接口返回 JSON 错误，不再回吐 HTML 造成静默失败
    return jsonResponse({ error: `未知后台接口: ${pathname}` }, 404);
}

// ======================== 默认配置（FIX-06：补齐前端所需字段） ========================
function generateDefaultConfig(hostname, uuid, env) {
    const now = new Date().toISOString();
    return {
        TIME: now,
        加载时间: now,
        HOST: hostname,
        HOSTS: [hostname],
        UUID: uuid,
        PATH: env.PATH || '/',
        完整节点路径: env.PATH || '/',
        协议类型: 'vless',
        传输协议: 'ws',
        跳过证书验证: false,
        启用0RTT: true,
        Fingerprint: 'chrome',
        LINK: '',
        ECHConfig: { DNS: '', SNI: '' },
        优选订阅生成: {
            local: true,
            SUBNAME: 'EdgeTunnel',
            SUBUpdateTime: 6,
            TOKEN: '',
            本地IP库: { 随机IP: true }
        },
        订阅转换配置: {
            SUBAPI: '',
            SUBLIST: true,
            SORT: false,
            EXPAND: true,
            APPEND_TYPE: false,
            UDP: true,
            XUDP: true,
            TLS13: true
        },
        反代: {
            PROXYIP: '',
            路径模板: ''
        },
        CF: { Email: '', GlobalAPIKey: '', AccountID: '', ZoneID: '' },
        TG: { 启用: false, Token: '', ChatID: '' },
        SS: { TLS: true },
        通知: { 启用: false },
        // 2.3.0：多协议与 UDP/DoH
        协议: {
            启用: env.PROTOCOLS || 'vless',
            trojan: { password: env.TROJAN_PASSWORD || uuid },
            ss: { method: env.SS_METHOD || 'aes-128-gcm', password: env.SS_PASSWORD || uuid },
            UDP: { 启用: true, DoH: env.DOH_URL || '' }
        }
    };
}

// ======================== 面板静态页（来源可配置） ========================
/**
 * 由于面板 HTML 默认托管在第三方 Pages，本仓库对 admin.html 的本地修改不会生效。
 * 因此在回源返回 /admin 页面时，动态注入「修改管理密码」组件，保证修复开箱可用。
 * 若你已把 frontend/ 自托管并通过 PAGES_BASE 指向，可设置 INJECT_PWD_WIDGET=false 关闭注入。
 */
const PWD_WIDGET_HTML = [
    '<div id="pwdChangeModal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);align-items:center;justify-content:center;">',
    '<div style="background:#fff;border-radius:14px;max-width:420px;width:92%;padding:22px 24px;box-shadow:0 18px 50px rgba(0,0,0,.28);font-family:system-ui,-apple-system,\'Segoe UI\',sans-serif;color:#1f2937;">',
    '<h3 style="margin:0 0 6px;font-size:18px;">修改管理密码</h3>',
    '<p id="pwdChangeTip" style="margin:0 0 16px;font-size:13px;color:#6b7280;line-height:1.6;">当前仍在使用出厂默认密码，为保障安全，请先修改密码后再进行其它操作。</p>',
    '<label style="display:block;font-size:13px;margin-bottom:6px;color:#374151;">当前密码</label>',
    '<input id="pwdOld" type="password" style="width:100%;padding:9px 11px;border:1px solid #d1d5db;border-radius:8px;margin-bottom:12px;box-sizing:border-box;font-size:14px;">',
    '<label style="display:block;font-size:13px;margin-bottom:6px;color:#374151;">新密码（至少 6 位）</label>',
    '<input id="pwdNew" type="password" style="width:100%;padding:9px 11px;border:1px solid #d1d5db;border-radius:8px;margin-bottom:12px;box-sizing:border-box;font-size:14px;">',
    '<label style="display:block;font-size:13px;margin-bottom:6px;color:#374151;">确认新密码</label>',
    '<input id="pwdNew2" type="password" style="width:100%;padding:9px 11px;border:1px solid #d1d5db;border-radius:8px;margin-bottom:14px;box-sizing:border-box;font-size:14px;">',
    '<div id="pwdChangeMsg" style="display:none;font-size:13px;margin-bottom:10px;padding:8px 10px;border-radius:7px;"></div>',
    '<div style="display:flex;gap:10px;justify-content:flex-end;">',
    '<button id="pwdCancelBtn" type="button" style="padding:8px 16px;border:1px solid #d1d5db;background:#fff;border-radius:8px;cursor:pointer;font-size:14px;">稍后</button>',
    '<button id="pwdSaveBtn" type="button" style="padding:8px 16px;border:0;background:#2563eb;color:#fff;border-radius:8px;cursor:pointer;font-size:14px;">保存</button>',
    '</div></div></div>',
    '<button id="pwdFabBtn" type="button" title="修改管理密码" style="position:fixed;right:18px;bottom:18px;z-index:99998;width:48px;height:48px;border-radius:50%;border:0;background:#2563eb;color:#fff;font-size:20px;cursor:pointer;box-shadow:0 8px 20px rgba(37,99,235,.4);">&#128273;</button>',
    '<div id="kvWarnBar" style="display:none;position:fixed;left:0;right:0;top:0;z-index:99997;background:#b45309;color:#fff;font-size:13px;padding:9px 16px;text-align:center;font-family:system-ui,sans-serif;line-height:1.5;"></div>'
].join('');

const PWD_WIDGET_JS = [
    '(function(){',
    'var modal=document.getElementById("pwdChangeModal"),oldEl=document.getElementById("pwdOld"),',
    'newEl=document.getElementById("pwdNew"),new2El=document.getElementById("pwdNew2"),',
    'msgEl=document.getElementById("pwdChangeMsg"),tipEl=document.getElementById("pwdChangeTip"),',
    'cancelBtn=document.getElementById("pwdCancelBtn"),saveBtn=document.getElementById("pwdSaveBtn"),',
    'fabBtn=document.getElementById("pwdFabBtn"),forced=false;',
    'function openModal(f){forced=!!f;tipEl.textContent=f?"当前仍在使用出厂默认密码，为保障安全，请先修改密码后再进行其它操作。":"修改后需使用新密码重新登录。";',
    'cancelBtn.style.display=f?"none":"";msgEl.style.display="none";oldEl.value="";newEl.value="";new2El.value="";modal.style.display="flex";}',
    'function closeModal(){modal.style.display="none";}',
    'function showMsg(t,ok){msgEl.style.display="block";msgEl.textContent=t;msgEl.style.background=ok?"#ecfdf5":"#fef2f2";msgEl.style.color=ok?"#065f46":"#991b1b";}',
    'fabBtn.addEventListener("click",function(){openModal(false);});',
    'cancelBtn.addEventListener("click",closeModal);',
    'modal.addEventListener("click",function(e){if(e.target===modal&&!forced)closeModal();});',
    'saveBtn.addEventListener("click",async function(){',
    'var o=oldEl.value,n=newEl.value,n2=new2El.value;',
    'if(n.length<6){showMsg("新密码至少 6 位",false);return;}',
    'if(n!==n2){showMsg("两次输入的新密码不一致",false);return;}',
    'saveBtn.disabled=true;saveBtn.textContent="提交中...";',
    'try{var r=await fetch("/admin/password",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({oldPassword:o,newPassword:n})});',
    'var d=await r.json().catch(function(){return {};});',
    'if(r.ok&&d.success){showMsg((d.message||"密码已修改")+"，即将跳转到登录页",true);setTimeout(function(){window.location.href="/login";},1600);}',
    'else{showMsg(d.message||d.error||"修改失败",false);}}catch(e){showMsg("请求失败："+e.message,false);}',
    'finally{saveBtn.disabled=false;saveBtn.textContent="保存";}});',
    'var kvBar=document.getElementById("kvWarnBar");',
    'async function checkStatus(){try{var r=await fetch("/admin/status?_t="+Date.now(),{cache:"no-store"});',
    'if(r.ok){var d=await r.json();if(d&&d.needChangePassword)openModal(true);',
    'if(d&&d.storage==="memory"&&kvBar){kvBar.innerHTML="⚠ 未检测到 KV 绑定：当前配置只存在内存中，Worker 冷启动后会丢失。请创建名为 <b>edgetunnel-kv</b> 的 KV 命名空间，binding 名填 <b>KV</b>，填入 ID 后重新部署。";kvBar.style.display="block";document.body.style.paddingTop="38px";}',
    'if(d&&d.storage==="kv"&&kvBar){kvBar.style.display="none";}}}catch(e){}}',
    'var of=window.fetch;window.fetch=async function(){var r=await of.apply(this,arguments);',
    'try{if(r&&r.status===403&&(r.headers.get("content-type")||"").indexOf("application/json")>=0){',
    'var c=r.clone(),d=await c.json();if(d&&d.needChangePassword){openModal(true);',
    'if(typeof showToast==="function")showToast("请先修改默认管理密码","error");}}}catch(e){}return r;};',
    'if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",checkStatus);else checkStatus();',
    '})();'
].join('');

function injectPasswordWidget(html) {
    const script = '<script>' + PWD_WIDGET_JS + '</script>';
    const widget = PWD_WIDGET_HTML + script;
    const idx = html.lastIndexOf('</body>');
    if (idx === -1) return html + widget;
    return html.slice(0, idx) + widget + html.slice(idx);
}

async function proxyStaticPages(env, subPath) {
    const base = (env.PAGES_BASE || DEFAULT_PAGES_BASE).trim().replace(/\/+$/, '');
    const targetUrl = base + subPath;
    try {
        const resp = await fetch(targetUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
        });
        const headers = new Headers(resp.headers);
        headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        headers.set('Pragma', 'no-cache');
        headers.set('Expires', '0');
        headers.delete('Set-Cookie');
        headers.delete('Set-Cookie2');

        const shouldInject = subPath.startsWith('/admin')
            && String(env.INJECT_PWD_WIDGET || 'true').toLowerCase() !== 'false';

        if (!shouldInject) {
            headers.delete('content-length');
            return new Response(resp.body, { status: resp.status, statusText: resp.statusText, headers });
        }

        const html = await resp.text();
        headers.delete('content-length');
        headers.delete('etag');
        headers.delete('content-encoding');
        return new Response(injectPasswordWidget(html), {
            status: resp.status,
            statusText: resp.statusText,
            headers
        });
    } catch (_) {
        // FIX-09：不再回显内部资源地址
        return new Response('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>面板加载失败</title></head>'
            + '<body><h3>面板静态资源加载失败</h3><p>请检查网络后刷新重试；也可在变量 PAGES_BASE 中指定自建的面板静态源站。</p></body></html>', {
            status: 200,
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
    }
}

// ======================== Cloudflare 用量查询 ========================
async function getCloudflareUsage(email, globalApiKey, accountId, zoneId) {
    if (!email || !globalApiKey || !zoneId) {
        return { msg: '缺少 Email / GlobalAPIKey / ZoneID 参数，无法查询用量', error: 'missing_params' };
    }
    const endpoint = `https://api.cloudflare.com/client/v4/zones/${encodeURIComponent(zoneId)}/analytics/dashboard?since=-10080&until=0&continuous=true`;
    const resp = await fetch(endpoint, {
        headers: {
            'X-Auth-Email': email,
            'X-Auth-Key': globalApiKey,
            'Content-Type': 'application/json'
        }
    });
    const data = await resp.json();
    if (!resp.ok) {
        throw new Error(data && data.errors && data.errors[0] ? data.errors[0].message : `HTTP ${resp.status}`);
    }
    const totals = (data.result && data.result.totals) || {};
    return {
        success: true,
        requests: (totals.requests && totals.requests.all) || 0,
        bandwidth: (totals.bandwidth && totals.bandwidth.all) || 0,
        threats: (totals.threats && totals.threats.all) || 0,
        pageviews: (totals.pageviews && totals.pageviews.all) || 0,
        raw: data.result || null
    };
}

// ======================== 订阅（FIX-07 / FIX-08） ========================
/**
 * 订阅（2.3.0）：
 *   - 支持 vless / trojan / shadowsocks 三种协议节点
 *   - 支持 target=clash|singbox|surge|quanx|loon|mixed|raw 内置转换
 *   - 支持配置外部 subconverter（SUBAPI）转发，失败自动回退内置转换
 */
function detectSubTarget(url, ua) {
    const t = (url.searchParams.get('target') || url.searchParams.get('fmt') || url.searchParams.get('type') || '').toLowerCase();
    if (t) return t;
    if (url.searchParams.has('clash')) return 'clash';
    if (url.searchParams.has('singbox') || url.searchParams.has('sing-box')) return 'singbox';
    if (url.searchParams.has('surge')) return 'surge';
    if (url.searchParams.has('quanx')) return 'quanx';
    if (url.searchParams.has('loon')) return 'loon';
    if (url.searchParams.has('raw')) return 'raw';
    if (ua.includes('clash') || ua.includes('mihomo') || ua.includes('meta')) return 'clash';
    if (ua.includes('sing-box')) return 'singbox';
    if (ua.includes('surge')) return 'surge';
    if (ua.includes('quantumult')) return 'quanx';
    if (ua.includes('loon')) return 'loon';
    return 'mixed';
}

function resolveEnabledProtocols(env, config) {
    const raw = (config && config.协议 && config.协议.启用) || env.PROTOCOLS || 'vless';
    const list = String(raw).split(/[,，\s]+/).map(s => s.trim().toLowerCase()).filter(Boolean);
    const allowed = list.filter(p => p === 'vless' || p === 'trojan' || p === 'ss' || p === 'shadowsocks');
    const normalized = allowed.map(p => (p === 'shadowsocks' ? 'ss' : p));
    return normalized.length ? Array.from(new Set(normalized)) : ['vless'];
}

/**
 * FIX-15：确定最终生效的 UUID。
 * 优先级：环境变量 UUID（显式设置且非出厂默认） > KV 中保存的 config.UUID > 兜底默认值。
 * 这样"改环境变量 UUID 后重新部署"能立即生效，不会被 KV 里的历史值永久盖住。
 */
function resolveEffectiveUuid(env, config, configuredUuid) {
    const envUuid = (env.UUID || '').trim().toLowerCase();
    if (envUuid && envUuid !== DEFAULT_UUID) return envUuid;
    const kvUuid = config && config.UUID ? String(config.UUID).trim().toLowerCase() : '';
    if (UUID_RE.test(kvUuid)) return kvUuid;
    return (configuredUuid || DEFAULT_UUID).trim().toLowerCase();
}

/**
 * 掩码显示 UUID：/version 未鉴权即可访问，不能把节点 UUID 明文广播出去。
 */
function maskUuid(uuid) {
    const s = String(uuid || '');
    if (!UUID_RE.test(s.toLowerCase())) return '';
    return s.slice(0, 8) + '-****-****-****-' + s.slice(24);
}

/**
 * 告知 UUID 当前由谁决定，避免"改了环境变量却不生效 / 面板改了被覆盖"的困惑。
 * env     = 环境变量 UUID 接管（面板里的 UUID 字段改了不生效，请改环境变量）
 * kv      = 使用后台保存的 UUID
 * default = 出厂默认值（强烈建议修改）
 */
function resolveUuidSource(env, config) {
    const envUuid = (env.UUID || '').trim().toLowerCase();
    if (envUuid && envUuid !== DEFAULT_UUID) return 'env';
    const kvUuid = config && config.UUID ? String(config.UUID).trim().toLowerCase() : '';
    if (UUID_RE.test(kvUuid) && kvUuid !== DEFAULT_UUID) return 'kv';
    return 'default';
}

/**
 * FIX-16：配置字段自愈。
 * KV 里可能存着旧版本/被清空的配置，直接返回会让面板表单全空。
 * 策略：以默认配置为底，用已保存配置中的"有效值"覆盖；
 * 空字符串 / null / undefined / 空数组不覆盖，避免把默认值冲掉。
 */
function isEmptyValue(v) {
    return v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0);
}

function deepMergeConfig(defaults, saved) {
    const out = Array.isArray(defaults) ? defaults.slice() : Object.assign({}, defaults);
    if (saved === null || typeof saved !== 'object') return out;
    if (Array.isArray(saved)) return saved.length ? saved : out;
    for (const key of Object.keys(saved)) {
        const sv = saved[key];
        if (isEmptyValue(sv)) continue;
        const dv = out[key];
        if (dv !== null && typeof dv === 'object' && !Array.isArray(dv)
            && sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            out[key] = deepMergeConfig(dv, sv);
        } else {
            out[key] = sv;
        }
    }
    return out;
}

async function buildNodeEntries(env, url, config, configuredUuid) {
    const nodes = await buildSubscriptionNodes(env, url, config);
    const hostname = url.hostname;
    // FIX-15：环境变量 UUID 必须优先于 KV 中保存的 config.UUID。
    // 原写法 (config.UUID || configuredUuid) 会让 KV 里的旧值永久盖住新环境变量：
    // 订阅发出旧 UUID、服务端却用环境变量校验 -> 握手必然失败、节点连不上。
    const uuid = resolveEffectiveUuid(env, config, configuredUuid);
    const path = normalizeWsPath(env.PATH);
    const ssPath = normalizeWsPath(env.SS_PATH || '/ss');
    const trojan = loadTrojanCredential(env, config);
    const ss = await loadSsCredential(env, config);
    const protocols = resolveEnabledProtocols(env, config);
    const subName = (config && config.优选订阅生成 && config.优选订阅生成.SUBNAME) || 'EdgeTunnel';

    const entries = [];
    for (const n of nodes) {
        const base = { address: n.address, port: n.port, remark: n.remark || n.address, host: hostname };
        for (const p of protocols) {
            if (p === 'vless') {
                entries.push({
                    ...base, protocol: 'vless', uuid, path,
                    name: protocols.length > 1 ? `${subName}-${n.remark || n.address}-VLESS` : `${subName}-${n.remark || n.address}`
                });
            } else if (p === 'trojan') {
                entries.push({
                    ...base, protocol: 'trojan', password: trojan.password, path,
                    name: protocols.length > 1 ? `${subName}-${n.remark || n.address}-Trojan` : `${subName}-${n.remark || n.address}`
                });
            } else if (p === 'ss' && ss) {
                entries.push({
                    ...base, protocol: 'ss', method: ss.method, password: ss.password, path: ssPath,
                    name: protocols.length > 1 ? `${subName}-${n.remark || n.address}-SS` : `${subName}-${n.remark || n.address}`
                });
            }
        }
    }
    return entries;
}

async function handleSubscriptionRouting(request, env, url, configuredUuid) {
    const hostname = url.hostname;
    const port = url.port && url.port !== '80' ? url.port : '443';
    const ua = (request.headers.get('User-Agent') || '').toLowerCase();
    const token = url.searchParams.get('token');
    const expectedToken = await md5Hex(hostname + configuredUuid);

    const requireToken = String(env.REQUIRE_SUB_TOKEN || 'false').toLowerCase() === 'true';
    if (token && token !== expectedToken) {
        return new Response('Invalid Subscription Token', { status: 403 });
    }
    if (!token && requireToken) {
        return new Response('Subscription Token Required', { status: 403 });
    }

    // FIX-14：记录订阅访问日志（Get_SUB），并做去重避免订阅刷新把日志刷爆
    pushAccessLogDedup(env, request, 'Get_SUB').catch(() => { });

    const config = await loadConfig(env, hostname, configuredUuid);
    const entries = await buildNodeEntries(env, url, config, configuredUuid);
    const target = detectSubTarget(url, ua);
    const userInfo = 'upload=0; download=0; total=107374182400; expire=4102329600';
    const commonHeaders = { 'Subscription-Userinfo': userInfo, 'Cache-Control': 'no-store' };

    // 外部 subconverter（可选）：force=api 强制走外部，force=local 强制内置
    const subApi = (config && config.订阅转换配置 && config.订阅转换配置.SUBAPI) || env.SUBAPI || '';
    const forceMode = (url.searchParams.get('convert') || '').toLowerCase();
    const builtInTargets = ['clash', 'singbox', 'mixed', 'raw', 'b64', 'base64', 'surge', 'quanx', 'loon'];
    const shouldUseApi = subApi.trim() && forceMode !== 'local'
        && (forceMode === 'api' || !builtInTargets.includes(target));

    if (shouldUseApi) {
        const selfUrl = `${url.protocol}//${url.host}/sub?token=${expectedToken}`;
        const sep = subApi.includes('?') ? '&' : '?';
        const apiUrl = `${subApi}${sep}target=${encodeURIComponent(target)}`
            + `&url=${encodeURIComponent(selfUrl)}`
            + `&config=${encodeURIComponent((config && config.订阅转换配置 && config.订阅转换配置.SUBCONFIG) || '')}`;
        try {
            const upstream = await fetch(apiUrl, { headers: { 'User-Agent': 'EdgeTunnel/2.3.0' } });
            if (upstream.ok) {
                const body = await upstream.text();
                await pushLog(env, 'info', `订阅转换使用外部 subconverter（target=${target}）`);
                return new Response(body, {
                    status: 200,
                    headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'external' }
                });
            }
            await pushLog(env, 'warn', `外部 subconverter 返回 HTTP ${upstream.status}，已回退内置转换`);
        } catch (err) {
            await pushLog(env, 'warn', `外部 subconverter 调用失败：${err.message}，已回退内置转换`);
        }
    }

    const links = entries.map(buildShareLink);
    const plain = links.join('\n');

    switch (target) {
        case 'clash':
            return new Response(buildClashConfig(entries, hostname), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/yaml; charset=utf-8', 'X-Converter': 'builtin' }
            });
        case 'singbox':
            return new Response(JSON.stringify(buildSingboxOutbound(entries, hostname), null, 2), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'application/json; charset=utf-8', 'X-Converter': 'builtin' }
            });
        case 'surge':
            return new Response(buildSurgeConfig(entries, hostname, port), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'builtin' }
            });
        case 'quanx':
            return new Response(buildQuanxConfig(entries, hostname, port), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'builtin' }
            });
        case 'loon':
            return new Response(buildLoonConfig(entries, hostname, port), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'builtin' }
            });
        case 'raw':
            return new Response(plain, {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'builtin' }
            });
        default:
            return new Response(base64Encode(plain), {
                status: 200,
                headers: { ...commonHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'X-Converter': 'builtin' }
            });
    }
}

async function loadConfig(env, hostname, uuid) {
    const defaults = generateDefaultConfig(hostname, uuid, env);
    const raw = await kvGet(env, 'config.json');
    if (raw) {
        try {
            const cfg = JSON.parse(raw);
            if (cfg && typeof cfg === 'object') {
                const merged = deepMergeConfig(defaults, cfg);           // FIX-16 字段自愈
                merged.UUID = resolveEffectiveUuid(env, cfg, uuid);      // FIX-15 环境变量优先
                merged.uuidSource = resolveUuidSource(env, cfg);
                return merged;
            }
        } catch (_) { }
    }
    return defaults;
}

function normalizeWsPath(p) {
    if (!p) return '/';
    let s = String(p).trim();
    if (!s.startsWith('/')) s = '/' + s;
    return s;
}

/**
 * 构建订阅节点地址：
 * 优先使用用户在后台保存的优选节点(ADD.txt)，否则使用 Worker 自身域名(HOSTS/hostname)。
 * 修复前：每次请求从 ProxyIP 池随机取一个作为节点地址，导致订阅内容不稳定且节点不可用。
 */
async function buildSubscriptionNodes(env, url, config) {
    const nodes = [];
    const addTxt = await kvGet(env, 'ADD.txt');
    if (addTxt && addTxt.trim() && addTxt.trim() !== 'null') {
        for (const line of addTxt.split(/[\r\n]+/)) {
            const item = line.trim();
            if (!item || item.startsWith('#')) continue;
            const m = item.match(/^(\[[0-9a-fA-F:]+\]|[A-Za-z0-9._-]+)(?::(\d+))?(?:#(.*))?$/);
            if (!m) continue;
            nodes.push({ address: m[1], port: (m[2] || '443'), remark: m[3] || m[1] });
        }
    }
    if (nodes.length > 0) return nodes;

    const hosts = (config && Array.isArray(config.HOSTS) && config.HOSTS.length) ? config.HOSTS : [url.hostname];
    for (const h of hosts) {
        const clean = String(h).trim();
        if (clean) nodes.push({ address: clean, port: '443', remark: clean });
    }
    if (nodes.length === 0) nodes.push({ address: url.hostname, port: '443', remark: url.hostname });
    return nodes;
}

// ---------- 分享链接（vless / trojan / ss） ----------
function buildShareLink(entry) {
    if (entry.protocol === 'vless') {
        const params = [
            'encryption=none',
            'security=tls',
            `sni=${encodeURIComponent(entry.host)}`,
            'fp=chrome',
            'type=ws',
            `host=${encodeURIComponent(entry.host)}`,
            `path=${encodeURIComponent(entry.path)}`
        ];
        return `vless://${entry.uuid}@${entry.address}:${entry.port}?${params.join('&')}#${encodeURIComponent(entry.name)}`;
    }
    if (entry.protocol === 'trojan') {
        const params = [
            'security=tls',
            `sni=${encodeURIComponent(entry.host)}`,
            'type=ws',
            `host=${encodeURIComponent(entry.host)}`,
            `path=${encodeURIComponent(entry.path)}`
        ];
        return `trojan://${encodeURIComponent(entry.password)}@${entry.address}:${entry.port}?${params.join('&')}#${encodeURIComponent(entry.name)}`;
    }
    if (entry.protocol === 'ss') {
        // SIP002：userinfo 为 base64(method:password)，WebSocket 走 v2ray-plugin
        const userinfo = base64Encode(`${entry.method}:${entry.password}`).replace(/=+$/, '');
        const plugin = `v2ray-plugin;mode=websocket;path=${entry.path};host=${entry.host};tls`;
        return `ss://${userinfo}@${entry.address}:${entry.port}?plugin=${encodeURIComponent(plugin)}#${encodeURIComponent(entry.name)}`;
    }
    return '';
}

// ---------- Clash / Mihomo ----------
function buildClashConfig(entries, hostname) {
    const names = [];
    const proxies = entries.map(e => {
        names.push(e.name);
        const wsOpts = [
            `    ws-opts:`,
            `      path: "${e.path}"`,
            `      headers:`,
            `        Host: ${hostname}`,
            `      max-early-data: 2048`,
            `      early-data-header-name: Sec-WebSocket-Protocol`
        ].join('\n');

        if (e.protocol === 'trojan') {
            return [
                `  - name: "${e.name}"`,
                `    type: trojan`,
                `    server: ${e.address}`,
                `    port: ${e.port}`,
                `    password: "${e.password}"`,
                `    udp: true`,
                `    sni: ${hostname}`,
                `    network: ws`,
                wsOpts
            ].join('\n');
        }
        if (e.protocol === 'ss') {
            return [
                `  - name: "${e.name}"`,
                `    type: ss`,
                `    server: ${e.address}`,
                `    port: ${e.port}`,
                `    cipher: ${e.method}`,
                `    password: "${e.password}"`,
                `    udp: true`,
                `    plugin: v2ray-plugin`,
                `    plugin-opts:`,
                `      mode: websocket`,
                `      host: ${hostname}`,
                `      path: "${e.path}"`,
                `      tls: true`,
                `      mux: false`
            ].join('\n');
        }
        return [
            `  - name: "${e.name}"`,
            `    type: vless`,
            `    server: ${e.address}`,
            `    port: ${e.port}`,
            `    uuid: ${e.uuid}`,
            `    udp: true`,
            `    tls: true`,
            `    servername: ${hostname}`,
            `    network: ws`,
            wsOpts
        ].join('\n');
    });

    return [
        'port: 7890',
        'socks-port: 7891',
        'allow-lan: false',
        'mode: rule',
        'log-level: info',
        'proxies:',
        ...proxies,
        'proxy-groups:',
        '  - name: "PROXY"',
        '    type: select',
        '    proxies:',
        ...names.map(n => `      - "${n}"`),
        'rules:',
        '  - MATCH,PROXY',
        ''
    ].join('\n');
}

// ---------- sing-box ----------
function buildSingboxOutbound(entries, hostname) {
    const wsTransport = (e) => ({
        type: 'ws',
        path: e.path,
        headers: { Host: hostname },
        max_early_data: 2048,
        early_data_header_name: 'Sec-WebSocket-Protocol'
    });
    return {
        outbounds: entries.map(e => {
            if (e.protocol === 'trojan') {
                return {
                    type: 'trojan',
                    tag: e.name,
                    server: e.address,
                    server_port: parseInt(e.port, 10) || 443,
                    password: e.password,
                    tls: { enabled: true, server_name: hostname, insecure: false },
                    transport: wsTransport(e)
                };
            }
            if (e.protocol === 'ss') {
                return {
                    type: 'shadowsocks',
                    tag: e.name,
                    server: e.address,
                    server_port: parseInt(e.port, 10) || 443,
                    method: e.method,
                    password: e.password,
                    plugin: 'v2ray-plugin',
                    plugin_opts: { mode: 'websocket', host: hostname, path: e.path, tls: true }
                };
            }
            return {
                type: 'vless',
                tag: e.name,
                server: e.address,
                server_port: parseInt(e.port, 10) || 443,
                uuid: e.uuid,
                tls: { enabled: true, server_name: hostname, insecure: false },
                transport: wsTransport(e)
            };
        })
    };
}

// ---------- Surge / Quantumult X / Loon ----------
function buildSurgeConfig(entries, hostname, port) {
    const lines = ['#!MANAGED-CONFIG', ''];
    lines.push('[Proxy]');
    for (const e of entries) {
        if (e.protocol === 'trojan') {
            lines.push(`${e.name} = trojan, ${e.address}, ${e.port}, password=${e.password}, sni=${hostname}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true`);
        } else if (e.protocol === 'ss') {
            lines.push(`${e.name} = ss, ${e.address}, ${e.port}, encrypt-method=${e.method}, password=${e.password}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true`);
        } else {
            lines.push(`${e.name} = vless, ${e.address}, ${e.port}, username=${e.uuid}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true, sni=${hostname}`);
        }
    }
    lines.push('');
    lines.push('[Proxy Group]');
    lines.push(`PROXY = select, ${entries.map(e => e.name).join(', ')}`);
    lines.push('');
    lines.push('[Rule]');
    lines.push('FINAL,PROXY');
    return lines.join('\n');
}

function buildQuanxConfig(entries, hostname, port) {
    const lines = [];
    for (const e of entries) {
        if (e.protocol === 'trojan') {
            lines.push(`trojan = ${e.address}:${e.port}, password=${e.password}, over-tls=true, tls-host=${hostname}, obfs=ws, obfs-host=${hostname}, obfs-uri=${e.path}, tag=${e.name}`);
        } else if (e.protocol === 'ss') {
            lines.push(`shadowsocks = ${e.address}:${e.port}, method=${e.method}, password=${e.password}, over-tls=true, tls-host=${hostname}, obfs=ws, obfs-host=${hostname}, obfs-uri=${e.path}, tag=${e.name}`);
        } else {
            lines.push(`vless = ${e.address}:${e.port}, method=none, password=${e.uuid}, udp-relay=true, over-tls=true, tls-host=${hostname}, obfs=ws, obfs-host=${hostname}, obfs-uri=${e.path}, tag=${e.name}`);
        }
    }
    return lines.join('\n');
}

function buildLoonConfig(entries, hostname, port) {
    const lines = ['[Proxy]'];
    for (const e of entries) {
        if (e.protocol === 'trojan') {
            lines.push(`${e.name} = trojan, ${e.address}, ${e.port}, ${e.password}, sni=${hostname}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true`);
        } else if (e.protocol === 'ss') {
            lines.push(`${e.name} = ss, ${e.address}, ${e.port}, encrypt-method=${e.method}, password=${e.password}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true`);
        } else {
            lines.push(`${e.name} = vless, ${e.address}, ${e.port}, username=${e.uuid}, ws=true, ws-path=${e.path}, ws-headers=Host:${hostname}, tls=true, sni=${hostname}`);
        }
    }
    lines.push('');
    lines.push('[Proxy Group]');
    lines.push(`PROXY = select, ${entries.map(e => e.name).join(', ')}`);
    lines.push('');
    lines.push('[Rule]');
    lines.push('FINAL,PROXY');
    return lines.join('\n');
}

// ======================== 抗探测反代（FIX-09） ========================
async function handleAntiProbingProxyPass(request, env) {
    const fallbackBase = (env.FALLBACK_SITE || env.URL || DEFAULT_FALLBACK_SITE).trim();
    let fallbackUrl;
    try {
        fallbackUrl = new URL(fallbackBase.startsWith('http') ? fallbackBase : 'https://' + fallbackBase);
    } catch (_) {
        fallbackUrl = new URL(DEFAULT_FALLBACK_SITE);
    }

    const clientUrl = new URL(request.url);
    fallbackUrl.pathname = clientUrl.pathname;
    fallbackUrl.search = clientUrl.search;

    const newHeaders = new Headers(request.headers);
    newHeaders.set('Host', fallbackUrl.host);
    newHeaders.set('Origin', fallbackUrl.origin);
    newHeaders.set('Referer', fallbackUrl.origin);

    const headersToRemove = [
        'cf-connecting-ip', 'cf-ray', 'cf-ipcountry', 'cf-visitor',
        'x-forwarded-proto', 'x-real-ip', 'upgrade', 'connection',
        'sec-websocket-key', 'sec-websocket-version', 'sec-websocket-protocol',
        'cookie'
    ];
    for (const h of headersToRemove) newHeaders.delete(h);

    try {
        const upstreamResp = await fetch(fallbackUrl.toString(), {
            method: request.method,
            headers: newHeaders,
            body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
            redirect: 'follow'
        });

        const respHeaders = new Headers(upstreamResp.headers);
        respHeaders.set('Server', 'nginx');
        respHeaders.delete('cf-ray');
        // 不回传上游 Cookie，避免把伪装站点的 Cookie 种到本站域名下
        respHeaders.delete('Set-Cookie');
        respHeaders.delete('Set-Cookie2');

        return new Response(upstreamResp.body, {
            status: upstreamResp.status,
            statusText: upstreamResp.statusText,
            headers: respHeaders
        });
    } catch (_) {
        return new Response('<!DOCTYPE html><html><head><title>Welcome</title></head><body><h1>Welcome to our service.</h1></body></html>', {
            status: 200,
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
    }
}

// ======================== 代理入口：VLESS / Trojan / Shadowsocks over WebSocket ========================
async function ssDeriveMasterKey(password, keyLen) {
    // EVP_BytesToKey(MD5)，与 Shadowsocks AEAD 客户端的口令派生方式一致
    const pwBytes = new TextEncoder().encode(password);
    const out = new Uint8Array(keyLen);
    let filled = 0;
    let prev = new Uint8Array(0);
    while (filled < keyLen) {
        const buf = new Uint8Array(prev.length + pwBytes.length);
        buf.set(prev, 0);
        buf.set(pwBytes, prev.length);
        const digest = new Uint8Array(await crypto.subtle.digest('MD5', buf));
        const take = Math.min(digest.length, keyLen - filled);
        out.set(digest.subarray(0, take), filled);
        filled += take;
        prev = digest;
    }
    return out;
}

async function loadSsCredential(env, config) {
    const method = String(
        (env.SS_METHOD || (config && config.协议 && config.协议.ss && config.协议.ss.method) || 'aes-128-gcm')
    ).trim().toLowerCase();
    const keyLen = SS_METHOD_KEY_LEN[method];
    if (!keyLen) return null;
    const password = String(
        (env.SS_PASSWORD || (config && config.协议 && config.协议.ss && config.协议.ss.password) || env.UUID || DEFAULT_UUID)
    ).trim();
    try {
        const key = await ssDeriveMasterKey(password, keyLen);
        return { method, keyLen, password, key };
    } catch (_) {
        return null; // 运行环境不支持 MD5 时 Shadowsocks 不可用
    }
}

function loadTrojanCredential(env, config) {
    const password = String(
        (env.TROJAN_PASSWORD || (config && config.协议 && config.协议.trojan && config.协议.trojan.password) || env.UUID || DEFAULT_UUID)
    ).trim();
    return { password, hex: sha224Hex(password) };
}

async function handleProxyWebSocket(request, env, configuredUuid) {
    const webSocketPair = new WebSocketPair();
    const [clientSocket, serverSocket] = Object.values(webSocketPair);
    const url = new URL(request.url);

    const expectedUuidBytes = getUuidBytes(configuredUuid);
    if (!expectedUuidBytes) {
        serverSocket.close(1008, 'Configuration Error');
        return new Response(null, { status: 101, webSocket: clientSocket });
    }

    const config = await loadConfig(env, url.hostname, configuredUuid);
    const trojan = loadTrojanCredential(env, config);
    const ssCredential = await loadSsCredential(env, config);
    const ssPath = normalizeWsPath(env.SS_PATH || '/ss');
    const dohUrl = (env.DOH_URL || DEFAULT_DOH_URL).trim();
    const forceSs = ssPath !== '/' && url.pathname === ssPath && !!ssCredential;

    const earlyDataHeader = request.headers.get('Sec-WebSocket-Protocol');
    let earlyDataBytes = null;
    let responseProtocolHeader = null;
    if (earlyDataHeader) {
        earlyDataBytes = base64UrlToUint8Array(earlyDataHeader);
        if (earlyDataBytes) responseProtocolHeader = earlyDataHeader;
    }

    serverSocket.accept();
    serverSocket.binaryType = 'arraybuffer';

    let mode = forceSs ? 'ss' : null;      // vless | trojan | ss
    let isUdpMode = false;
    let ssInbound = null;
    let ssOutbound = null;
    let udpReader = null;
    let remoteTcpSocket = null;
    let tcpWriter = null;
    let headerParsed = false;
    let lastActiveTime = Date.now();
    let isCleanedUp = false;

    const watchdogInterval = setInterval(() => {
        if (Date.now() - lastActiveTime > IDLE_TIMEOUT_MS) cleanup();
    }, 15000);

    const cleanup = () => {
        if (isCleanedUp) return;
        isCleanedUp = true;
        clearInterval(watchdogInterval);
        try { if (tcpWriter) tcpWriter.releaseLock(); } catch (_) { }
        try { if (remoteTcpSocket) remoteTcpSocket.close(); } catch (_) { }
        try { serverSocket.close(); } catch (_) { }
    };

    serverSocket.addEventListener('close', cleanup);
    serverSocket.addEventListener('error', cleanup);

    const writeTcp = async (bytes) => {
        if (!tcpWriter) return;
        if (tcpWriter.desiredSize !== null && tcpWriter.desiredSize <= 0) await tcpWriter.ready;
        await tcpWriter.write(bytes);
    };

    const openTcp = async (address, port) => {
        remoteTcpSocket = await establishOutboundTcp(address, port, env);
        tcpWriter = remoteTcpSocket.writable.getWriter();
        pumpDownlink(remoteTcpSocket, serverSocket, () => { lastActiveTime = Date.now(); }, cleanup, {
            mode,
            vlessPrefix: mode === 'vless',
            getSsOutbound: async () => {
                if (!ssOutbound) ssOutbound = new SsOutboundStream(ssCredential.key);
                return ssOutbound;
            }
        });
    };

    /** UDP：Workers 无 UDP socket，仅把 :53 的 DNS 查询转 DoH 后回封 */
    const drainUdp = async () => {
        if (!udpReader) return;
        for (let guard = 0; guard < 64; guard++) {
            const pkt = udpReader.next();
            if (!pkt) break;
            if (pkt.hasError) {
                await pushLog(env, 'warn', `UDP 报文解析失败：${pkt.message}`);
                continue;
            }
            if (pkt.port !== DNS_PORT) {
                await pushLog(env, 'warn', `UDP 目标端口 ${pkt.address}:${pkt.port} 不支持（Workers 无 UDP socket，仅支持 53 端口的 DNS over HTTPS）`);
                continue;
            }
            try {
                const answer = await resolveDnsOverHttps(pkt.data, dohUrl);
                if (serverSocket.readyState === 1) serverSocket.send(encodeUdpResponse(answer));
                lastActiveTime = Date.now();
            } catch (err) {
                await pushLog(env, 'warn', `DoH 查询失败(${pkt.address})：${err.message}`);
            }
        }
    };

    const enterUdpMode = async (initialPayload) => {
        isUdpMode = true;
        udpReader = new UdpPacketReader();
        if (initialPayload && initialPayload.byteLength > 0) udpReader.append(initialPayload);
        await drainUdp();
    };

    const processChunk = async (chunk) => {
        lastActiveTime = Date.now();

        if (!headerParsed) {
            if (mode === null) {
                if (chunk.byteLength >= 24 && chunk[0] === 0 && constantTimeCompare(chunk, expectedUuidBytes, 1, 16)) {
                    mode = 'vless';
                } else if (chunk.byteLength >= 58 && constantTimeEqualString(new TextDecoder().decode(chunk.subarray(0, 56)), trojan.hex)) {
                    mode = 'trojan';
                } else {
                    await pushLog(env, 'warn', `无法识别的代理协议首包（${chunk.byteLength} 字节，路径 ${url.pathname}）`);
                    cleanup();
                    return;
                }
            }

            if (mode === 'vless') {
                const result = parseVlessHeader(chunk, expectedUuidBytes);
                if (result.hasError) {
                    await pushLog(env, 'warn', `VLESS 首包解析失败：${result.message}`);
                    cleanup();
                    return;
                }
                headerParsed = true;
                if (result.isUdp) {
                    await enterUdpMode(result.rawPayload);
                    return;
                }
                await openTcp(result.address, result.port);
                if (result.rawPayload && result.rawPayload.byteLength > 0) await writeTcp(result.rawPayload);
                return;
            }

            if (mode === 'trojan') {
                const result = parseTrojanHeader(chunk, trojan.hex);
                if (result.hasError) {
                    await pushLog(env, 'warn', `Trojan 首包解析失败：${result.message}`);
                    cleanup();
                    return;
                }
                headerParsed = true;
                if (result.isUdp) {
                    await enterUdpMode(result.rawPayload);
                    return;
                }
                await openTcp(result.address, result.port);
                if (result.rawPayload && result.rawPayload.byteLength > 0) await writeTcp(result.rawPayload);
                return;
            }

            // Shadowsocks：无特征头，需要完整解出 salt + 长度块 + 地址块
            if (!ssInbound) ssInbound = new SsInboundStream(ssCredential.key);
            ssInbound.append(chunk);
            const payloads = await ssInbound.pump();
            if (!ssInbound.headerParsed) return;
            headerParsed = true;
            await openTcp(ssInbound.target.address, ssInbound.target.port);
            for (const p of payloads) await writeTcp(p);
            return;
        }

        if (isUdpMode) {
            udpReader.append(chunk);
            await drainUdp();
            return;
        }

        if (mode === 'ss') {
            ssInbound.append(chunk);
            const payloads = await ssInbound.pump();
            for (const p of payloads) await writeTcp(p);
            return;
        }

        await writeTcp(chunk);
    };

    serverSocket.addEventListener('message', async (event) => {
        try {
            await processChunk(new Uint8Array(event.data));
        } catch (err) {
            await pushLog(env, 'warn', `数据处理异常：${err && err.message ? err.message : err}`);
            cleanup();
        }
    });

    if (earlyDataBytes && earlyDataBytes.byteLength > 0) {
        processChunk(earlyDataBytes).catch(() => cleanup());
    }

    const responseHeaders = new Headers();
    if (responseProtocolHeader) {
        responseHeaders.set('Sec-WebSocket-Protocol', responseProtocolHeader);
    }

    return new Response(null, { status: 101, webSocket: clientSocket, headers: responseHeaders });
}

function parseVlessHeader(buffer, expectedUuidBytes) {
    if (buffer.byteLength < 24) return { hasError: true, message: 'Header too short' };

    const version = buffer[0];
    if (version !== 0) return { hasError: true, message: `Unsupported version: ${version}` };
    if (!constantTimeCompare(buffer, expectedUuidBytes, 1, 16)) {
        return { hasError: true, message: 'Invalid UUID' };
    }

    const addonLen = buffer[17];
    const cmdIndex = 18 + addonLen;
    if (buffer.byteLength < cmdIndex + 4) return { hasError: true, message: 'Truncated command' };

    const command = buffer[cmdIndex];
    const isUdp = (command === 2);
    if (command !== 1 && command !== 2) {
        return { hasError: true, message: `Unsupported command: ${command}` };
    }

    const portIndex = cmdIndex + 1;
    const port = (buffer[portIndex] << 8) | buffer[portIndex + 1];

    const addressType = buffer[portIndex + 2];
    let addrIndex = portIndex + 3;
    let targetAddress = '';

    switch (addressType) {
        case 1:
            if (buffer.byteLength < addrIndex + 4) return { hasError: true, message: 'Truncated IPv4' };
            targetAddress = `${buffer[addrIndex]}.${buffer[addrIndex + 1]}.${buffer[addrIndex + 2]}.${buffer[addrIndex + 3]}`;
            addrIndex += 4;
            break;
        case 2: {
            if (buffer.byteLength < addrIndex + 1) return { hasError: true, message: 'Truncated domain' };
            const domainLen = buffer[addrIndex];
            addrIndex += 1;
            if (buffer.byteLength < addrIndex + domainLen) return { hasError: true, message: 'Truncated domain body' };
            targetAddress = new TextDecoder().decode(buffer.subarray(addrIndex, addrIndex + domainLen));
            addrIndex += domainLen;
            break;
        }
        case 3: {
            if (buffer.byteLength < addrIndex + 16) return { hasError: true, message: 'Truncated IPv6' };
            const ipv6Parts = [];
            for (let i = 0; i < 8; i++) {
                ipv6Parts.push(((buffer[addrIndex + i * 2] << 8) | buffer[addrIndex + i * 2 + 1]).toString(16));
            }
            targetAddress = ipv6Parts.join(':');
            addrIndex += 16;
            break;
        }
        default:
            return { hasError: true, message: `Invalid address type: ${addressType}` };
    }

    const rawPayload = buffer.subarray(addrIndex);
    return { hasError: false, version, isUdp, port, address: targetAddress, rawPayload };
}

async function establishOutboundTcp(address, port, env) {
    try {
        const directSocket = connect({ hostname: address, port });
        await directSocket.opened;
        return directSocket;
    } catch (_) {
        const proxyIp = await getBestProxyIP(env);
        try {
            const proxiedSocket = connect({ hostname: proxyIp, port });
            await proxiedSocket.opened;
            return proxiedSocket;
        } catch (proxyErr) {
            throw new Error(`连接失败: ${proxyErr.message}`);
        }
    }
}

/**
 * TCP 下行 -> WebSocket。
 * opts.mode：
 *   vless  —— 首个响应包前加 2 字节 [0,0]（VLESS 响应头）
 *   trojan —— 原样转发，不加任何头
 *   ss     —— 用 Shadowsocks 响应流加密后发送（首个包会带上服务端 salt）
 */
async function pumpDownlink(tcpSocket, webSocket, onActiveCallback, cleanupCallback, opts = {}) {
    let reader = null;
    let isFirstPacket = true;
    let ssOutbound = null;

    const sendBytes = (bytes) => {
        if (webSocket.readyState !== WebSocket.OPEN) return false;
        webSocket.send(bytes);
        return true;
    };

    try {
        reader = tcpSocket.readable.getReader();
        while (true) {
            if (webSocket.bufferedAmount > HIGH_WATER_MARK) {
                while (webSocket.bufferedAmount > LOW_WATER_MARK) {
                    if (webSocket.readyState !== WebSocket.OPEN) return;
                    await sleep(15);
                }
            }

            const { done, value } = await reader.read();
            if (done) break;
            if (!value || value.byteLength === 0) continue;
            if (webSocket.readyState !== WebSocket.OPEN) break;

            onActiveCallback();

            if (opts.mode === 'ss' && typeof opts.getSsOutbound === 'function') {
                if (!ssOutbound) ssOutbound = await opts.getSsOutbound();
                const frames = await ssOutbound.sealChunks(new Uint8Array(value));
                for (const frame of frames) {
                    if (!sendBytes(frame)) return;
                }
                continue;
            }

            if (isFirstPacket && opts.vlessPrefix) {
                isFirstPacket = false;
                const totalLen = VLESS_RESP_HEADER.byteLength + value.byteLength;
                const mergedBuf = globalBufferPool.acquire(totalLen);
                mergedBuf.set(VLESS_RESP_HEADER, 0);
                mergedBuf.set(value, VLESS_RESP_HEADER.byteLength);
                // FIX-12：先拷贝再回收，避免缓冲区被其它连接复用导致串包
                if (!sendBytes(mergedBuf.slice(0, totalLen))) return;
                globalBufferPool.release(mergedBuf);
            } else {
                isFirstPacket = false;
                if (!sendBytes(value)) return;
            }
        }
    } catch (_) {
    } finally {
        if (reader) {
            try { await reader.cancel(); } catch (_) { }
            try { reader.releaseLock(); } catch (_) { }
        }
        cleanupCallback();
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ======================== Cron 优选轮换 ========================
async function handleScheduledProxyCheck(env) {
    if (storageMode(env) === 'memory') {
        console.warn('[Cron] 未检测到绑定的 KV 空间，测速结果仅保留在内存');
    }

    let candidates = DEFAULT_PROXY_IPS;
    if (env.PROXYIP) {
        const custom = env.PROXYIP.split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean);
        if (custom.length > 0) candidates = custom;
    }

    const results = await Promise.allSettled(candidates.map(ip => measureTcpLatency(ip, 443, 2500)));
    let bestIp = null;
    let minLatency = Infinity;
    for (const res of results) {
        if (res.status === 'fulfilled' && res.value.healthy && res.value.latency < minLatency) {
            minLatency = res.value.latency;
            bestIp = res.value.ip;
        }
    }

    if (bestIp) {
        await kvPut(env, 'BEST_PROXY_IP', bestIp, { expirationTtl: 600 });
        await pushLog(env, 'info', `ProxyIP 优选完成：${bestIp} (${minLatency}ms)`);
        cachedBestProxyIP = bestIp;
        cacheExpiryTimestamp = Date.now() + 30000;
    }
}

async function measureTcpLatency(ip, port = 443, timeoutMs = 2500) {
    const startTime = Date.now();
    let socket = null;
    try {
        const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), timeoutMs));
        socket = connect({ hostname: ip, port });
        await Promise.race([socket.opened, timeoutPromise]);
        return { ip, healthy: true, latency: Date.now() - startTime };
    } catch (_) {
        return { ip, healthy: false, latency: Infinity };
    } finally {
        if (socket) { try { socket.close(); } catch (_) { } }
    }
}
