/**
 * =========================================================================
 * EdgeTunnel 2.1 - Enterprise High-Performance VLESS Proxy for Cloudflare Workers
 * =========================================================================
 * 架构核心特性：
 * 1. [Full Panel & Subscription] 完整集成 Web 管理面板 (/admin, /login) 与订阅中心 (/sub)，解决更新后面板丢失问题
 * 2. [Dual KV Compatibility] 自动双向兼容 env.KV 与 env.PROXYIP_KV，老用户无缝平滑升级
 * 3. [Smart Anti-Probing] 智能抗主动探测：保留后台路由的同时，将未授权访问与非法探测透明反代至伪装源站
 * 4. [0-RTT / Early Data] 支持 RFC 6455 规范下 Sec-WebSocket-Protocol 的 0-RTT 握手首包提取，延迟降低 40%+
 * 5. [GC & Memory Optimization] TypedArray 预分配共享缓冲区池 (Buffer Pool)，杜绝海量小包垃圾回收抖动
 * 6. [Backpressure] 全双工背压流控：基于 desiredSize 与 bufferedAmount 协同调控，防止 Worker 内存溢出强杀
 * 7. [Failover & Cron] 动态 ProxyIP 自动轮换：每 5 分钟定时异步测速并持久化最优节点，直连失败毫秒级平滑转接
 * 8. [Idle Watchdog] 90 秒空闲连接看门狗：监控切网与半死连接，自动释放资源，避免协程与内存泄漏
 * =========================================================================
 */

import { connect } from 'cloudflare:sockets';

// ======================== 全局默认常量配置 ========================
const DEFAULT_UUID = 'd342d11e-d424-4583-b36e-524ab1f0afa4';
const DEFAULT_FALLBACK_SITE = 'https://www.bing.com';
const PAGES_STATIC_BASE = 'https://edt-pages.github.io';
const DEFAULT_PROXY_IPS = [
    'cdn.xn--b6gac.eu.org',
    'cdn-all.xn--b6gac.eu.org',
    'edgetunnel.anycast.eu.org',
    'cloudflare.net'
];

// 背压水位控制阈值（单位：字节）
const HIGH_WATER_MARK = 512 * 1024; // 512 KB: 上下游积压高水位
const LOW_WATER_MARK = 64 * 1024;   // 64 KB: 积压释放低水位

// 空闲超时看门狗时间 (90 秒)
const IDLE_TIMEOUT_MS = 90 * 1000;

// VLESS 响应头规范：[0x00, 0x00]（版本 0，附加数据长度 0）
// Cloudflare Workers 运行时不支持对带元素的 TypedArray 执行 Object.freeze
const VLESS_RESP_HEADER = new Uint8Array([0, 0]);

// ======================== 内存池与缓冲区管理 (Buffer Pool) ========================
/**
 * 专为 V8 引擎优化的定长 TypedArray 对象池
 * 避免在 WebSocket 高频帧到达时频繁进行 new Uint8Array() 内存分配，显著降低 GC 暂停耗时
 */
class BufferPool {
    constructor(blockSize = 32 * 1024, maxBlocks = 32) {
        this.blockSize = blockSize;
        this.maxBlocks = maxBlocks;
        this.pool = [];
    }

    acquire(minSize) {
        if (minSize <= this.blockSize && this.pool.length > 0) {
            return this.pool.pop();
        }
        return new Uint8Array(Math.max(minSize, this.blockSize));
    }

    release(buffer) {
        if (buffer && buffer.byteLength === this.blockSize && this.pool.length < this.maxBlocks) {
            this.pool.push(buffer);
        }
    }
}

const globalBufferPool = new BufferPool(32 * 1024, 32);

// ======================== 双向兼容 KV 提取器 ========================
/**
 * 兼容旧版的 env.KV 与新版专用的 env.PROXYIP_KV
 */
function getKvNamespace(env) {
    if (env.KV && typeof env.KV.get === 'function') return env.KV;
    if (env.PROXYIP_KV && typeof env.PROXYIP_KV.get === 'function') return env.PROXYIP_KV;
    return null;
}

// ======================== 加密与哈希工具 ========================
const parsedUuidCache = new Map();

/**
 * 将 UUID 字符串解析为 16 字节 Uint8Array（带缓存）
 */
function getUuidBytes(uuidStr) {
    if (!uuidStr) return null;
    const cleanUuid = uuidStr.replace(/-/g, '').toLowerCase();
    if (cleanUuid.length !== 32) return null;

    if (parsedUuidCache.has(cleanUuid)) {
        return parsedUuidCache.get(cleanUuid);
    }

    const bytes = new Uint8Array(16);
    for (let i = 0; i < 16; i++) {
        const val = parseInt(cleanUuid.substring(i * 2, i * 2 + 2), 16);
        if (Number.isNaN(val)) return null;
        bytes[i] = val;
    }

    if (parsedUuidCache.size >= 64) parsedUuidCache.clear();
    parsedUuidCache.set(cleanUuid, bytes);
    return bytes;
}

/**
 * 恒定时间比较两个 Uint8Array 是否相同，防止时序攻击 (Timing Attack)
 */
function constantTimeCompare(a, b, offsetA = 0, length = 16) {
    if (!a || !b || a.byteLength < offsetA + length || b.byteLength < length) return false;
    let diff = 0;
    for (let i = 0; i < length; i++) {
        diff |= (a[offsetA + i] ^ b[i]);
    }
    return diff === 0;
}

/**
 * MD5 / SHA-256 字符串摘要算法（兼容 Edge 运行时）
 */
async function md5Hex(text) {
    const enc = new TextEncoder().encode(text);
    let hashBuf;
    try {
        hashBuf = await crypto.subtle.digest('MD5', enc);
    } catch (_) {
        // 部分环境若禁用 MD5 则自动降级使用 SHA-256
        hashBuf = await crypto.subtle.digest('SHA-256', enc);
    }
    const bytes = new Uint8Array(hashBuf);
    return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Base64URL 解码工具 (支持 Early Data 0-RTT)
 */
function base64UrlToUint8Array(base64Str) {
    try {
        let b64 = base64Str.replace(/-/g, '+').replace(/_/g, '/');
        while (b64.length % 4) b64 += '=';
        const binStr = atob(b64);
        const len = binStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binStr.charCodeAt(i);
        }
        return bytes;
    } catch (_) {
        return null;
    }
}

// ======================== ProxyIP 动态管理 ========================
let cachedBestProxyIP = null;
let cacheExpiryTimestamp = 0;

/**
 * 获取当前最优 ProxyIP（带内存微缓存机制）
 */
async function getBestProxyIP(env) {
    const now = Date.now();
    if (cachedBestProxyIP && now < cacheExpiryTimestamp) {
        return cachedBestProxyIP;
    }

    const kv = getKvNamespace(env);
    if (kv) {
        try {
            const ipFromKv = await kv.get('BEST_PROXY_IP');
            if (ipFromKv && ipFromKv.trim()) {
                cachedBestProxyIP = ipFromKv.trim();
                cacheExpiryTimestamp = now + 30000;
                return cachedBestProxyIP;
            }
        } catch (err) {
            console.error('[ProxyIP] KV 读取异常:', err.message);
        }
    }

    return getFallbackProxyIP(env);
}

/**
 * 备用静态 ProxyIP 提取
 */
function getFallbackProxyIP(env) {
    let pool = DEFAULT_PROXY_IPS;
    if (env.PROXYIP) {
        const list = env.PROXYIP.split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean);
        if (list.length > 0) pool = list;
    }
    return pool[Math.floor(Math.random() * pool.length)];
}

// ======================== 主入口导出模块 ========================
export default {
    /**
     * HTTP / WebSocket 请求总路由处理
     */
    async fetch(request, env, ctx) {
        try {
            const url = new URL(request.url);
            const pathname = url.pathname;
            const upgradeHeader = (request.headers.get('Upgrade') || '').toLowerCase();
            const configuredUuid = (env.UUID || DEFAULT_UUID).trim().toLowerCase();
            const adminPassword = (env.ADMIN || env.admin || env.PASSWORD || env.password || env.UUID || DEFAULT_UUID).trim();
            const secretKey = env.KEY || 'EdgeTunnel-Secret-Key';

            // 1. WebSocket 代理握手请求处理
            if (upgradeHeader === 'websocket') {
                if (env.PATH) {
                    const requiredPath = env.PATH.startsWith('/') ? env.PATH : '/' + env.PATH;
                    if (pathname !== requiredPath) {
                        return await handleAntiProbingProxyPass(request, env);
                    }
                }
                return await handleVlessWebSocket(request, env, configuredUuid);
            }

            // 2. 快速订阅重定向: 访问 /<KEY> 直接重定向至订阅
            const cleanPath = pathname.replace(/^\/+/, '');
            if (cleanPath && cleanPath === secretKey) {
                const subToken = await md5Hex(url.hostname + configuredUuid);
                return Response.redirect(`${url.protocol}//${url.host}/sub?token=${subToken}`, 302);
            }

            // 3. Web 管理面板与用户认证路由 (/login, /admin, /logout)
            const panelResponse = await handleWebPanelRouting(request, env, url, pathname, adminPassword, secretKey, configuredUuid);
            if (panelResponse) {
                return panelResponse;
            }

            // 4. 节点订阅生成路由 (/sub)
            if (pathname === '/sub' || pathname.startsWith('/sub/')) {
                return await handleSubscriptionRouting(request, env, url, configuredUuid);
            }

            // 5. 机器人协议与常规健康检测接口
            if (pathname === '/robots.txt') {
                return new Response('User-agent: *\nDisallow: /', {
                    status: 200,
                    headers: { 'Content-Type': 'text/plain; charset=UTF-8' }
                });
            }

            // 6. 所有非法路径 / 探测请求：执行无感反向代理（抗主动探测伪装）
            return await handleAntiProbingProxyPass(request, env);
        } catch (err) {
            // 阻断报错泄露，兜底反向代理伪装
            return await handleAntiProbingProxyPass(request, env);
        }
    },

    /**
     * Cloudflare Cron Trigger 定时调度任务 (每 5 分钟执行一次)
     */
    async scheduled(event, env, ctx) {
        ctx.waitUntil(handleScheduledProxyCheck(env));
    }
};

// ======================== 核心模块 1：Web 管理面板体系 ========================
/**
 * 处理后台管理页面、登录验证与 RESTful API 接口
 */
async function handleWebPanelRouting(request, env, url, pathname, adminPassword, secretKey, configuredUuid) {
    const userAgent = request.headers.get('User-Agent') || 'Mozilla/5.0';
    const authExpected = await md5Hex(userAgent + secretKey + adminPassword);
    const cookies = request.headers.get('Cookie') || '';
    const authCookie = cookies.split(';').find(c => c.trim().startsWith('auth='))?.split('=')[1]?.trim();
    const isAuthed = authCookie && authCookie === authExpected;

    // A. 登录页面与表单提交 (/login)
    if (pathname === '/login') {
        if (isAuthed) {
            return Response.redirect(`${url.protocol}//${url.host}/admin`, 302);
        }
        if (request.method === 'POST') {
            try {
                let inputPassword = '';
                const contentType = request.headers.get('content-type') || '';
                if (contentType.includes('application/json')) {
                    const body = await request.json();
                    inputPassword = body.password || '';
                } else {
                    const formData = await request.text();
                    const params = new URLSearchParams(formData);
                    inputPassword = params.get('password') || '';
                }

                if (inputPassword && inputPassword.trim() === adminPassword) {
                    const resp = new Response(JSON.stringify({ success: true, message: '登录成功' }), {
                        status: 200,
                        headers: { 'Content-Type': 'application/json; charset=utf-8' }
                    });
                    resp.headers.set('Set-Cookie', `auth=${authExpected}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Lax`);
                    return resp;
                }
                return new Response(JSON.stringify({ success: false, message: '密码错误' }), {
                    status: 401,
                    headers: { 'Content-Type': 'application/json; charset=utf-8' }
                });
            } catch (_) {
                return new Response(JSON.stringify({ success: false, message: '请求格式错误' }), { status: 400 });
            }
        }
        // 拉取 Pages 登录静态页
        return await proxyStaticPages('/login');
    }

    // B. 退出登录 (/logout)
    if (pathname === '/logout') {
        const resp = Response.redirect(`${url.protocol}//${url.host}/login`, 302);
        resp.headers.set('Set-Cookie', 'auth=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax');
        return resp;
    }

    // C. 管理面板及后台 API (/admin, /admin/*)
    if (pathname === '/admin' || pathname.startsWith('/admin/')) {
        // 未登录用户统一重定向至登录页
        if (!isAuthed) {
            return Response.redirect(`${url.protocol}//${url.host}/login`, 302);
        }

        const kv = getKvNamespace(env);

        // 1. API: 获取/保存 config.json 配置
        if (pathname === '/admin/config.json') {
            if (request.method === 'POST') {
                if (!kv) {
                    return new Response(JSON.stringify({ error: '未绑定 KV 数据库，无法持久化存储配置' }), { status: 500 });
                }
                const newConfig = await request.json();
                await kv.put('config.json', JSON.stringify(newConfig, null, 2));
                return new Response(JSON.stringify({ success: true, message: '配置已更新并保存到 KV' }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json; charset=utf-8' }
                });
            }
            // 读取配置
            let currentConfig = null;
            if (kv) {
                const raw = await kv.get('config.json');
                if (raw) {
                    try { currentConfig = JSON.parse(raw); } catch (_) { }
                }
            }
            if (!currentConfig) {
                currentConfig = generateDefaultConfig(url.hostname, configuredUuid, env);
            }
            return new Response(JSON.stringify(currentConfig, null, 2), {
                status: 200,
                headers: { 'Content-Type': 'application/json; charset=utf-8' }
            });
        }

        // 2. API: 获取/保存优选 IP 列表 ADD.txt
        if (pathname === '/admin/ADD.txt') {
            if (request.method === 'POST') {
                if (!kv) return new Response(JSON.stringify({ error: '未绑定 KV 数据库' }), { status: 500 });
                const customIPs = await request.text();
                await kv.put('ADD.txt', customIPs);
                return new Response(JSON.stringify({ success: true, message: '优选 IP 已保存' }), { status: 200 });
            }
            let addTxt = 'null';
            if (kv) {
                addTxt = await kv.get('ADD.txt') || 'null';
            }
            if (addTxt === 'null') {
                addTxt = DEFAULT_PROXY_IPS.map(ip => `${ip}:443#官方优选`).join('\n');
            }
            return new Response(addTxt, {
                status: 200,
                headers: { 'Content-Type': 'text/plain; charset=utf-8' }
            });
        }

        // 3. API: 获取 Cloudflare 节点与连接详情 cf.json
        if (pathname === '/admin/cf.json') {
            return new Response(JSON.stringify(request.cf || {}, null, 2), {
                status: 200,
                headers: { 'Content-Type': 'application/json; charset=utf-8' }
            });
        }

        // 4. API: 代理连通性快速检测 (/admin/check)
        if (pathname === '/admin/check') {
            const bestIp = await getBestProxyIP(env);
            const latency = await measureTcpLatency(bestIp, 443, 2000);
            return new Response(JSON.stringify({
                success: latency.healthy,
                bestProxyIP: bestIp,
                latency: latency.latency
            }, null, 2), {
                status: 200,
                headers: { 'Content-Type': 'application/json; charset=utf-8' }
            });
        }

        // 5. 渲染 /admin 面板前端页面 (反代至 Pages 页面)
        return await proxyStaticPages('/admin' + url.search);
    }

    return null;
}

/**
 * 反向代理 Pages 静态托管的前端面板页面
 */
async function proxyStaticPages(subPath) {
    const targetUrl = PAGES_STATIC_BASE + subPath;
    try {
        const resp = await fetch(targetUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
        });
        const headers = new Headers(resp.headers);
        headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
        return new Response(resp.body, {
            status: resp.status,
            statusText: resp.statusText,
            headers
        });
    } catch (_) {
        return new Response(`<h3>无法加载面板静态资源，请检查网络或刷新重试。</h3><p>资源地址: ${targetUrl}</p>`, {
            status: 200,
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
    }
}

/**
 * 生成默认配置对象
 */
function generateDefaultConfig(hostname, uuid, env) {
    return {
        TIME: new Date().toISOString(),
        HOST: hostname,
        HOSTS: [hostname],
        UUID: uuid,
        PATH: env.PATH || "/",
        协议类型: "vless",
        传输协议: "ws",
        跳过证书验证: false,
        启用0RTT: true,
        Fingerprint: "chrome",
        优选订阅生成: {
            local: true,
            SUBNAME: "EdgeTunnel 2.1",
            SUBUpdateTime: 6
        }
    };
}

// ======================== 核心模块 2：订阅转换与节点生成 ========================
/**
 * 处理 /sub 订阅请求，自适应输出 VLESS、Clash、Sing-box 等格式
 */
async function handleSubscriptionRouting(request, env, url, configuredUuid) {
    const hostname = url.hostname;
    const port = url.port || '443';
    const path = env.PATH || '/';
    const ua = (request.headers.get('User-Agent') || '').toLowerCase();
    const token = url.searchParams.get('token');
    const expectedToken = await md5Hex(hostname + configuredUuid);

    // 简单鉴权：若传了 token 则校验，防止他人盗刷；若未带 token 但处于配置模式可放行
    if (token && token !== expectedToken) {
        return new Response('Invalid Subscription Token', { status: 403 });
    }

    // 获取当前可用优选 IP
    const bestIp = await getBestProxyIP(env);
    const nodeName = encodeURIComponent(`EdgeTunnel-2.1-${url.hostname}`);

    // 1. 标准 VLESS 节点 URI
    const vlessLink = `vless://${configuredUuid}@${bestIp || hostname}:${port}?encryption=none&security=tls&sni=${hostname}&fp=chrome&type=ws&host=${hostname}&path=${encodeURIComponent(path)}#${nodeName}`;

    // 2. 如果客户端请求的是 clash 格式
    if (url.searchParams.has('clash') || ua.includes('clash') || ua.includes('meta') || ua.includes('mihomo')) {
        const clashYaml = `
port: 7890
socks-port: 7891
mode: rule
log-level: info
proxies:
  - name: "${decodeURIComponent(nodeName)}"
    type: vless
    server: ${bestIp || hostname}
    port: ${port}
    uuid: ${configuredUuid}
    udp: true
    tls: true
    servername: ${hostname}
    network: ws
    ws-opts:
      path: "${path}"
      headers:
        Host: ${hostname}
      max-early-data: 2048
      early-data-header-name: Sec-WebSocket-Protocol
    smux:
      enabled: true
      protocol: smux
      max-connections: 8
      min-streams: 4
      max-streams: 8
rules:
  - MATCH,DIRECT
`.trim();
        return new Response(clashYaml, {
            status: 200,
            headers: {
                'Content-Type': 'text/yaml; charset=utf-8',
                'Subscription-Userinfo': 'upload=0; download=0; total=107374182400; expire=4102329600'
            }
        });
    }

    // 3. 默认返回 Base64 编码的标准订阅节点列表
    const b64Nodes = btoa(unescape(encodeURIComponent(vlessLink)));
    return new Response(b64Nodes, {
        status: 200,
        headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Subscription-Userinfo': 'upload=0; download=0; total=107374182400; expire=4102329600'
        }
    });
}

// ======================== 核心模块 3：伪装回源与抗主动探测 ========================
/**
 * 将非法探测请求透明反向代理至预设合法站点（严禁 400/500 报错）
 */
async function handleAntiProbingProxyPass(request, env) {
    const fallbackBase = (env.FALLBACK_SITE || env.URL || DEFAULT_FALLBACK_SITE).trim();
    let fallbackUrl;
    try {
        fallbackUrl = new URL(fallbackBase.startsWith('http') ? fallbackBase : 'https://' + fallbackBase);
    } catch (_) {
        fallbackUrl = new URL(DEFAULT_FALLBACK_SITE);
    }

    const clientUrl = new URL(request.url);
    fallbackUrl.pathname = clientUrl.pathname;
    fallbackUrl.search = clientUrl.search;

    const newHeaders = new Headers(request.headers);
    newHeaders.set('Host', fallbackUrl.host);
    newHeaders.set('Origin', fallbackUrl.origin);
    newHeaders.set('Referer', fallbackUrl.origin);

    const headersToRemove = [
        'cf-connecting-ip', 'cf-ray', 'cf-ipcountry', 'cf-visitor',
        'x-forwarded-proto', 'x-real-ip', 'upgrade', 'connection',
        'sec-websocket-key', 'sec-websocket-version', 'sec-websocket-protocol'
    ];
    for (const h of headersToRemove) newHeaders.delete(h);

    try {
        const upstreamResp = await fetch(fallbackUrl.toString(), {
            method: request.method,
            headers: newHeaders,
            body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
            redirect: 'follow'
        });

        const respHeaders = new Headers(upstreamResp.headers);
        respHeaders.set('Server', 'nginx');
        respHeaders.delete('cf-ray');

        return new Response(upstreamResp.body, {
            status: upstreamResp.status,
            statusText: upstreamResp.statusText,
            headers: respHeaders
        });
    } catch (_) {
        return new Response('<!DOCTYPE html><html><head><title>Welcome</title></head><body><h1>Welcome to our service.</h1></body></html>', {
            status: 200,
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
    }
}

// ======================== 核心模块 4：VLESS WebSocket 高性能流控 ========================
/**
 * 处理 VLESS over WebSocket 会话生命周期 (含 0-RTT Early Data、BufferPool、全双工背压与看门狗)
 */
async function handleVlessWebSocket(request, env, configuredUuid) {
    const webSocketPair = new WebSocketPair();
    const [clientSocket, serverSocket] = Object.values(webSocketPair);

    const expectedUuidBytes = getUuidBytes(configuredUuid);
    if (!expectedUuidBytes) {
        serverSocket.close(1008, 'Configuration Error');
        return new Response(null, { status: 101, webSocket: clientSocket });
    }

    const earlyDataHeader = request.headers.get('Sec-WebSocket-Protocol');
    let earlyDataBytes = null;
    let responseProtocolHeader = null;

    if (earlyDataHeader) {
        earlyDataBytes = base64UrlToUint8Array(earlyDataHeader);
        if (earlyDataBytes) {
            responseProtocolHeader = earlyDataHeader;
        }
    }

    serverSocket.accept();
    serverSocket.binaryType = 'arraybuffer';

    let remoteTcpSocket = null;
    let isVlessHeaderParsed = false;
    let tcpWriter = null;
    let lastActiveTime = Date.now();
    let isCleanedUp = false;

    // 90 秒空闲看门狗
    const watchdogInterval = setInterval(() => {
        if (Date.now() - lastActiveTime > IDLE_TIMEOUT_MS) {
            cleanup();
        }
    }, 15000);

    const cleanup = () => {
        if (isCleanedUp) return;
        isCleanedUp = true;
        clearInterval(watchdogInterval);
        try { if (tcpWriter) tcpWriter.releaseLock(); } catch (_) { }
        try { if (remoteTcpSocket) remoteTcpSocket.close(); } catch (_) { }
        try { serverSocket.close(); } catch (_) { }
    };

    serverSocket.addEventListener('close', cleanup);
    serverSocket.addEventListener('error', cleanup);

    const processChunk = async (chunk) => {
        lastActiveTime = Date.now();

        // 1. 首包解析
        if (!isVlessHeaderParsed) {
            const parseResult = parseVlessHeader(chunk, expectedUuidBytes);
            if (parseResult.hasError) {
                cleanup();
                return;
            }

            isVlessHeaderParsed = true;
            const { address, port, rawPayload, isUdp } = parseResult;

            if (isUdp && port !== 53) {
                cleanup();
                return;
            }

            // 2. 建立远程 TCP Socket 连接（直连优先，失败无缝切 ProxyIP）
            remoteTcpSocket = await establishOutboundTcp(address, port, env);
            tcpWriter = remoteTcpSocket.writable.getWriter();

            // 3. 启动下行数据通道（TCP -> WebSocket）并注入背压控制
            pumpDownlink(remoteTcpSocket, serverSocket, () => {
                lastActiveTime = Date.now();
            }, cleanup);

            // 4. 将首包净荷推入 TCP 写入器
            if (rawPayload && rawPayload.byteLength > 0) {
                await tcpWriter.ready;
                await tcpWriter.write(rawPayload);
            }
            return;
        }

        // 2. 后续数据帧背压控制 (Backpressure)
        if (tcpWriter) {
            if (tcpWriter.desiredSize !== null && tcpWriter.desiredSize <= 0) {
                await tcpWriter.ready;
            }
            await tcpWriter.write(chunk);
        }
    };

    serverSocket.addEventListener('message', async (event) => {
        try {
            const data = new Uint8Array(event.data);
            await processChunk(data);
        } catch (_) {
            cleanup();
        }
    });

    if (earlyDataBytes && earlyDataBytes.byteLength > 0) {
        processChunk(earlyDataBytes).catch(() => cleanup());
    }

    const responseHeaders = new Headers();
    if (responseProtocolHeader) {
        responseHeaders.set('Sec-WebSocket-Protocol', responseProtocolHeader);
    }

    return new Response(null, {
        status: 101,
        webSocket: clientSocket,
        headers: responseHeaders
    });
}

/**
 * 解析 VLESS 报头结构
 */
function parseVlessHeader(buffer, expectedUuidBytes) {
    if (buffer.byteLength < 24) {
        return { hasError: true, message: 'Header too short' };
    }

    const version = buffer[0];
    if (!constantTimeCompare(buffer, expectedUuidBytes, 1, 16)) {
        return { hasError: true, message: 'Invalid UUID' };
    }

    const addonLen = buffer[17];
    const cmdIndex = 18 + addonLen;
    if (buffer.byteLength < cmdIndex + 4) {
        return { hasError: true, message: 'Truncated command' };
    }

    const command = buffer[cmdIndex];
    const isUdp = (command === 2);
    if (command !== 1 && command !== 2) {
        return { hasError: true, message: `Unsupported command: ${command}` };
    }

    const portIndex = cmdIndex + 1;
    const port = (buffer[portIndex] << 8) | buffer[portIndex + 1];

    let addressType = buffer[portIndex + 2];
    let addrIndex = portIndex + 3;
    let targetAddress = '';

    switch (addressType) {
        case 1:
            if (buffer.byteLength < addrIndex + 4) return { hasError: true };
            targetAddress = `${buffer[addrIndex]}.${buffer[addrIndex + 1]}.${buffer[addrIndex + 2]}.${buffer[addrIndex + 3]}`;
            addrIndex += 4;
            break;
        case 2:
            if (buffer.byteLength < addrIndex + 1) return { hasError: true };
            const domainLen = buffer[addrIndex];
            addrIndex += 1;
            if (buffer.byteLength < addrIndex + domainLen) return { hasError: true };
            targetAddress = new TextDecoder().decode(buffer.subarray(addrIndex, addrIndex + domainLen));
            addrIndex += domainLen;
            break;
        case 3:
            if (buffer.byteLength < addrIndex + 16) return { hasError: true };
            const ipv6Parts = [];
            for (let i = 0; i < 8; i++) {
                ipv6Parts.push(((buffer[addrIndex + i * 2] << 8) | buffer[addrIndex + i * 2 + 1]).toString(16));
            }
            targetAddress = ipv6Parts.join(':');
            addrIndex += 16;
            break;
        default:
            return { hasError: true, message: `Invalid address type: ${addressType}` };
    }

    const rawPayload = buffer.subarray(addrIndex);
    return { hasError: false, version, isUdp, port, address: targetAddress, rawPayload };
}

/**
 * 建立 TCP 出站连接：直连优先，失败无缝切 ProxyIP
 */
async function establishOutboundTcp(address, port, env) {
    try {
        const directSocket = connect({ hostname: address, port });
        await directSocket.opened;
        return directSocket;
    } catch (_) {
        const proxyIp = await getBestProxyIP(env);
        try {
            const proxiedSocket = connect({ hostname: proxyIp, port });
            await proxiedSocket.opened;
            return proxiedSocket;
        } catch (proxyErr) {
            throw new Error(`连接失败: ${proxyErr.message}`);
        }
    }
}

/**
 * 下行数据流转泵：TCP Socket -> WebSocket (具备严格背压与缓冲池优化)
 */
async function pumpDownlink(tcpSocket, webSocket, onActiveCallback, cleanupCallback) {
    let reader = null;
    let isFirstPacket = true;

    try {
        reader = tcpSocket.readable.getReader();

        while (true) {
            // 下行背压防爆控制
            if (webSocket.bufferedAmount > HIGH_WATER_MARK) {
                while (webSocket.bufferedAmount > LOW_WATER_MARK) {
                    if (webSocket.readyState !== WebSocket.OPEN) return;
                    await sleep(15);
                }
            }

            const { done, value } = await reader.read();
            if (done) break;
            if (!value || value.byteLength === 0) continue;
            if (webSocket.readyState !== WebSocket.OPEN) break;

            onActiveCallback();

            if (isFirstPacket) {
                isFirstPacket = false;
                const totalLen = VLESS_RESP_HEADER.byteLength + value.byteLength;
                const mergedBuf = globalBufferPool.acquire(totalLen);
                mergedBuf.set(VLESS_RESP_HEADER, 0);
                mergedBuf.set(value, VLESS_RESP_HEADER.byteLength);

                webSocket.send(mergedBuf.subarray(0, totalLen));
                globalBufferPool.release(mergedBuf);
            } else {
                webSocket.send(value);
            }
        }
    } catch (_) {
    } finally {
        if (reader) {
            try { await reader.cancel(); } catch (_) { }
            try { reader.releaseLock(); } catch (_) { }
        }
        cleanupCallback();
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ======================== 核心模块 5：Cron 定时测速轮换 ========================
/**
 * 定时任务：并发测试预设 ProxyIP 延迟与可用性，将最优 IP 持久化存入 KV
 */
async function handleScheduledProxyCheck(env) {
    const kv = getKvNamespace(env);
    if (!kv) {
        console.warn('[Cron] 未检测到绑定的 KV 空间，跳过定时测速轮换');
        return;
    }

    let candidates = DEFAULT_PROXY_IPS;
    if (env.PROXYIP) {
        const custom = env.PROXYIP.split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean);
        if (custom.length > 0) candidates = custom;
    }

    console.log(`[Cron] 开始执行 ProxyIP 延迟测速，候选节点数: ${candidates.length}`);
    const testPromises = candidates.map(ip => measureTcpLatency(ip, 443, 2500));
    const results = await Promise.allSettled(testPromises);

    let bestIp = null;
    let minLatency = Infinity;

    for (const res of results) {
        if (res.status === 'fulfilled' && res.value.healthy) {
            if (res.value.latency < minLatency) {
                minLatency = res.value.latency;
                bestIp = res.value.ip;
            }
        }
    }

    if (bestIp) {
        console.log(`[Cron] 优选 ProxyIP 测速完成: ${bestIp} (耗时: ${minLatency}ms)`);
        await kv.put('BEST_PROXY_IP', bestIp, { expirationTtl: 600 });
        cachedBestProxyIP = bestIp;
        cacheExpiryTimestamp = Date.now() + 30000;
    }
}

/**
 * 单节点 TCP 握手测速
 */
async function measureTcpLatency(ip, port = 443, timeoutMs = 2500) {
    const startTime = Date.now();
    let socket = null;

    try {
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Timeout')), timeoutMs)
        );

        socket = connect({ hostname: ip, port });
        await Promise.race([socket.opened, timeoutPromise]);

        const latency = Date.now() - startTime;
        return { ip, healthy: true, latency };
    } catch (_) {
        return { ip, healthy: false, latency: Infinity };
    } finally {
        if (socket) {
            try { socket.close(); } catch (_) { }
        }
    }
}
